'use strict';
const express   = require('express');
const http      = require('http');
const WebSocket = require('ws');
const crypto    = require('crypto');
const helmet    = require('helmet');
const morgan    = require('morgan');
const cors      = require('cors');
const rateLimit = require('express-rate-limit');
const path      = require('path');
const fs        = require('fs');

const PORT            = process.env.PORT        || 3000;
const GLOBAL_PASSWORD = process.env.APP_PASSWORD || 'MeCa12345@123';
const SESSION_TTL_MS  = 8 * 60 * 60 * 1000;

// ─── PERSISTENCIA DE DISPOSITIVOS ─────────────────────────────────────────────
const DEVICES_FILE = path.join(__dirname, 'devices.json');

function loadDevices() {
  try {
    if (fs.existsSync(DEVICES_FILE)) {
      const data = JSON.parse(fs.readFileSync(DEVICES_FILE, 'utf8'));
      data.forEach(function(d) {
        devices.set(d.code, {
          code: d.code, label: d.label,
          registeredAt: new Date(d.registeredAt),
          ws: null, online: false, lastSeen: null,
          viewers: new Set(), phoneNumber: d.phoneNumber || null,
          lastBattery: d.lastBattery, lastCharging: d.lastCharging || false
        });
      });
      console.log('[db] ' + devices.size + ' dispositivo(s) cargado(s) desde disco');
    }
  } catch(e) {
    console.error('[db] Error cargando dispositivos:', e.message);
  }
}

function saveDevices() {
  try {
    const data = [];
    devices.forEach(function(d) {
      data.push({
        code: d.code, label: d.label,
        registeredAt: d.registeredAt,
        phoneNumber: d.phoneNumber || null,
        lastBattery: d.lastBattery,
        lastCharging: d.lastCharging || false
      });
    });
    fs.writeFileSync(DEVICES_FILE, JSON.stringify(data, null, 2));
  } catch(e) {
    console.error('[db] Error guardando dispositivos:', e.message);
  }
}

const devices  = new Map();
const sessions = new Map();

loadDevices(); // cargar dispositivos guardados al arrancar

function generateDeviceCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const seg = function() {
    return Array.from({length:3}, function() {
      return chars[Math.floor(Math.random()*chars.length)];
    }).join('');
  };
  let c;
  do { c = seg()+'-'+seg()+'-'+seg(); } while (devices.has(c));
  return c;
}

function generateToken() { return crypto.randomBytes(32).toString('hex'); }

function verifyPassword(input) {
  const h = function(s){ return crypto.createHash('sha256').update(s).digest('hex'); };
  return crypto.timingSafeEqual(Buffer.from(h(input)), Buffer.from(h(GLOBAL_PASSWORD)));
}

function requireAuth(req, res, next) {
  const token = req.headers['x-session-token'] || req.query.token;
  if (!token) return res.status(401).json({ error: 'Sin autenticacion' });
  const s = sessions.get(token);
  if (!s) return res.status(401).json({ error: 'Sesion invalida' });
  if (Date.now() - s.createdAt > SESSION_TTL_MS) {
    sessions.delete(token);
    return res.status(401).json({ error: 'Sesion expirada' });
  }
  req.session = s;
  next();
}

function requireCookie(req, res, next) {
  const m = (req.headers.cookie || '').match(/(?:^|;\s*)gl_session=([^;]+)/);
  const token = m ? m[1] : null;
  if (!token) return res.redirect('/login');
  const s = sessions.get(token);
  if (!s || Date.now() - s.createdAt > SESSION_TTL_MS) {
    if (token) sessions.delete(token);
    res.setHeader('Set-Cookie', 'gl_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict');
    return res.redirect('/login');
  }
  req.session = s;
  next();
}

// ─── HTML LOGIN ───────────────────────────────────────────────────────────────
const HTML_LOGIN = '<!DOCTYPE html>\n' +
'<html lang="es">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width,initial-scale=1">\n' +
'<title>GuardianLink</title>\n' +
'<link rel="icon" type="image/png" href="/icon.png">\n' +
'<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">\n' +
'<style>\n' +
'*{box-sizing:border-box;margin:0;padding:0}\n' +
'body{font-family:\'Inter\',sans-serif;background:#0a0a0a;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px}\n' +
'.card{background:#111;border-radius:14px;padding:36px 30px;width:100%;max-width:480px;border:1px solid #1e1e1e;box-shadow:0 30px 80px rgba(0,0,0,.7)}\n' +
'.logo{text-align:center;margin-bottom:20px}\n' +
'.logo svg{width:52px;height:52px;fill:#00ff41;filter:drop-shadow(0 0 10px #00ff4180)}\n' +
'h1{color:#f1f5f9;font-size:1.4rem;font-weight:700;text-align:center;margin-bottom:4px}\n' +
'.sub{color:#444;text-align:center;font-size:.78rem;margin-bottom:26px;font-family:monospace}\n' +
'.dev{background:#0d0d0d;border:1.5px solid #2a2a2a;border-radius:10px;padding:16px;margin-bottom:10px;transition:border-color .2s}\n' +
'.dev.bad{border-color:#ff3333!important}\n' +
'.dh{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}\n' +
'.badge{background:#00ff41;color:#000;border-radius:4px;padding:2px 9px;font-size:.72rem;font-weight:700;font-family:monospace}\n' +
'.dname{color:#555;font-size:.73rem;font-family:monospace;margin-left:8px}\n' +
'.rm{background:none;border:none;color:#333;cursor:pointer;font-size:.75rem;padding:3px 7px}\n' +
'.rm:hover{color:#ff4444}\n' +
'.row{display:grid;grid-template-columns:1.3fr 1fr;gap:10px}\n' +
'.fg{display:flex;flex-direction:column;gap:5px}\n' +
'.lbl{color:#555;font-size:.68rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;font-family:monospace}\n' +
'input{width:100%;padding:10px 12px;background:#050505;border:1.5px solid #2a2a2a;border-radius:7px;color:#e2e8f0;font-size:.9rem;outline:none;font-family:monospace;transition:border-color .2s}\n' +
'input:focus{border-color:#00ff41}\n' +
'input.bad{border-color:#ff3333!important}\n' +
'input.good{border-color:#00ff41!important}\n' +
'input::placeholder{color:#252525}\n' +
'.fm{font-size:.73rem;font-family:monospace;min-height:16px;margin-top:3px;font-weight:600}\n' +
'.fm.e{color:#ff5555}.fm.o{color:#00ff41}.fm.w{color:#ffaa00}\n' +
'.hint{color:#2e2e2e;font-size:.62rem;font-family:monospace;margin-top:3px}\n' +
'.add-btn{width:100%;padding:10px;background:transparent;border:1px dashed #232323;border-radius:8px;color:#333;font-size:.8rem;cursor:pointer;transition:all .2s;margin-bottom:12px}\n' +
'.add-btn:hover{border-color:#00ff41;color:#00ff41}\n' +
'.sep{border:none;border-top:1px solid #191919;margin:14px 0}\n' +
'.go{width:100%;padding:14px;background:#00ff41;border:none;border-radius:9px;color:#000;font-size:1rem;font-weight:700;cursor:pointer;letter-spacing:.04em;transition:background .15s}\n' +
'.go:hover:not(:disabled){background:#00e639}\n' +
'.go:disabled{background:#181818;color:#2a2a2a;cursor:not-allowed}\n' +
'#errBox{display:none;margin-top:14px;padding:14px 16px;background:#cc0000;color:#fff;border-radius:8px;font-size:.88rem;font-family:monospace;font-weight:700;line-height:1.7;border:2px solid #ff4444}\n' +
'#errBox.on{display:block}\n' +
'#okBox{display:none;margin-top:14px;padding:12px 16px;background:#003300;color:#00ff41;border-radius:8px;font-size:.85rem;font-family:monospace;font-weight:700;border:2px solid #00ff41}\n' +
'#okBox.on{display:block}\n' +
'.spin{display:inline-block;width:14px;height:14px;border:2px solid rgba(0,0,0,.2);border-top-color:#000;border-radius:50%;animation:sp .7s linear infinite;margin-right:6px;vertical-align:middle}\n' +
'@keyframes sp{to{transform:rotate(360deg)}}\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
'<div class="card">\n' +
'  <div class="logo">\n' +
'    <svg viewBox="0 0 24 24"><path d="M12,1L3,5v6c0,5.55,3.84,10.74,9,12,5.16-1.26,9-6.45,9-12V5L12,1zm-2,16-4-4,1.41-1.41L10,14.17l6.59-6.59L18,9l-8,8z"/></svg>\n' +
'  </div>\n' +
'  <h1>GuardianLink</h1>\n' +
'  <p class="sub">Panel de monitoreo remoto</p>\n' +
'  <div class="dev" id="dev-1">\n' +
'    <div class="dh">\n' +
'      <div style="display:flex;align-items:center">\n' +
'        <span class="badge">CH1</span>\n' +
'        <span class="dname" id="dn-1">TEL&Eacute;FONO 1</span>\n' +
'      </div>\n' +
'    </div>\n' +
'    <div class="row">\n' +
'      <div class="fg">\n' +
'        <span class="lbl">C&oacute;digo del tel&eacute;fono</span>\n' +
'        <input type="text" id="code-1" placeholder="AAA-BBB-CCC" maxlength="11"\n' +
'               autocomplete="off" spellcheck="false"\n' +
'               oninput="FC(this,1)" onblur="CK(1)">\n' +
'        <div class="fm" id="cm-1"></div>\n' +
'        <div class="hint">Aparece en la app del tel&eacute;fono</div>\n' +
'      </div>\n' +
'      <div class="fg">\n' +
'        <span class="lbl">Contrase&ntilde;a</span>\n' +
'        <input type="password" id="pass-1" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"\n' +
'               autocomplete="current-password"\n' +
'               oninput="CP(1)" onblur="VP(1)">\n' +
'        <div class="fm" id="pm-1"></div>\n' +
'      </div>\n' +
'    </div>\n' +
'  </div>\n' +
'  <div id="xtr"></div>\n' +
'  <hr class="sep">\n' +
'  <button class="add-btn" onclick="ADD()">+ Agregar otro tel&eacute;fono</button>\n' +
'  <button class="go" id="goBtn" onclick="LOGIN()">Acceder al panel</button>\n' +
'  <div id="errBox"></div>\n' +
'  <div id="okBox">&#10003; Credenciales correctas &mdash; entrando...</div>\n' +
'</div>\n' +
'<script>\n' +
'var N=20,cnt=1,tmr={};\n' +
'function FC(el,i){\n' +
'  var raw=el.value.replace(/[^A-Za-z0-9]/g,"").toUpperCase().slice(0,9);\n' +
'  var out=raw;\n' +
'  if(raw.length>6) out=raw.slice(0,3)+"-"+raw.slice(3,6)+"-"+raw.slice(6);\n' +
'  else if(raw.length>3) out=raw.slice(0,3)+"-"+raw.slice(3);\n' +
'  el.value=out;\n' +
'  SF("cm-"+i,"code-"+i,"","");\n' +
'  if(raw.length===9){clearTimeout(tmr[i]);tmr[i]=setTimeout(function(){CK(i);},600);}\n' +
'}\n' +
'function CP(i){SF("pm-"+i,"pass-"+i,"","");}\n' +
'function SF(mid,fid,txt,cls){\n' +
'  var m=document.getElementById(mid),f=document.getElementById(fid);\n' +
'  if(m){m.textContent=txt;m.className="fm"+(cls?" "+cls:"");}\n' +
'  if(f){f.classList.remove("bad","good");if(cls==="e")f.classList.add("bad");if(cls==="o")f.classList.add("good");}\n' +
'}\n' +
'function SE(txt){\n' +
'  var b=document.getElementById("errBox");\n' +
'  document.getElementById("okBox").classList.remove("on");\n' +
'  b.innerHTML="&#9888; "+txt.split("\\n").join("<br>");\n' +
'  b.classList.add("on");\n' +
'}\n' +
'function HE(){document.getElementById("errBox").classList.remove("on");}\n' +
'function CK(i){\n' +
'  var el=document.getElementById("code-"+i);if(!el)return;\n' +
'  var c=el.value.trim().toUpperCase();if(!c)return;\n' +
'  if(!/^[A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{3}$/.test(c)){SF("cm-"+i,"code-"+i,"Formato: AAA-BBB-CCC","e");return;}\n' +
'  SF("cm-"+i,"code-"+i,"Verificando...","w");\n' +
'  fetch("/api/check-device",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:c})})\n' +
'  .then(function(r){return r.json();}).then(function(d){\n' +
'    if(d.exists){\n' +
'      SF("cm-"+i,"code-"+i,"OK "+(d.label||"")+" "+(d.online?"[EN LINEA]":"[OFFLINE]"),"o");\n' +
'      var n=document.getElementById("dn-"+i);if(n&&d.label)n.textContent=d.label.toUpperCase();\n' +
'    }else SF("cm-"+i,"code-"+i,"No encontrado - abre la app primero","e");\n' +
'  }).catch(function(){SF("cm-"+i,"code-"+i,"Sin conexion","w");});\n' +
'}\n' +
'function VP(i){\n' +
'  var el=document.getElementById("pass-"+i);if(!el||!el.value)return;\n' +
'  SF("pm-"+i,"pass-"+i,"Verificando...","w");\n' +
'  fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:el.value})})\n' +
'  .then(function(r){\n' +
'    if(r.ok)SF("pm-"+i,"pass-"+i,"Contrasena correcta","o");\n' +
'    else SF("pm-"+i,"pass-"+i,"Contrasena incorrecta","e");\n' +
'  }).catch(function(){SF("pm-"+i,"pass-"+i,"Sin conexion","w");});\n' +
'}\n' +
'function ADD(){\n' +
'  if(cnt>=N)return;cnt++;var i=cnt;\n' +
'  var d=document.createElement("div");d.className="dev";d.id="dev-"+i;\n' +
'  d.innerHTML=\'<div class="dh"><div style="display:flex;align-items:center">\'+\n' +
'    \'<span class="badge">CH\'+i+\'</span>\'+\n' +
'    \'<span class="dname" id="dn-\'+i+\'">TELEFONO \'+i+\'</span></div>\'+\n' +
'    \'<button class="rm" onclick="RM(\'+i+\')">x Quitar</button></div>\'+\n' +
'    \'<div class="row"><div class="fg"><span class="lbl">Codigo</span>\'+\n' +
'    \'<input type="text" id="code-\'+i+\'" placeholder="AAA-BBB-CCC" maxlength="11" autocomplete="off" spellcheck="false" oninput="FC(this,\'+i+\')" onblur="CK(\'+i+\')">\'+\n' +
'    \'<div class="fm" id="cm-\'+i+\'"></div><div class="hint">Aparece en la app</div></div>\'+\n' +
'    \'<div class="fg"><span class="lbl">Contrasena</span>\'+\n' +
'    \'<input type="password" id="pass-\'+i+\'" placeholder="password" autocomplete="current-password" oninput="CP(\'+i+\')" onblur="VP(\'+i+\')">\'+\n' +
'    \'<div class="fm" id="pm-\'+i+\'"></div></div></div>\';\n' +
'  document.getElementById("xtr").appendChild(d);\n' +
'  setTimeout(function(){var e=document.getElementById("code-"+i);if(e)e.focus();},50);\n' +
'}\n' +
'function RM(i){var e=document.getElementById("dev-"+i);if(e)e.remove();}\n' +
'function LOGIN(){\n' +
'  HE();\n' +
'  var btn=document.getElementById("goBtn");\n' +
'  var blocks=document.querySelectorAll(".dev"),list=[],bad=false;\n' +
'  for(var i=0;i<blocks.length;i++){\n' +
'    var b=blocks[i],idx=b.id.replace("dev-","");\n' +
'    var ci=document.getElementById("code-"+idx),pi=document.getElementById("pass-"+idx);\n' +
'    if(!ci||!pi)continue;\n' +
'    var code=ci.value.trim().toUpperCase(),pass=pi.value,ok=true;\n' +
'    if(!code){SF("cm-"+idx,"code-"+idx,"Ingresa el codigo","e");ok=false;bad=true;}\n' +
'    else if(!/^[A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{3}$/.test(code)){SF("cm-"+idx,"code-"+idx,"Formato incorrecto","e");ok=false;bad=true;}\n' +
'    if(!pass){SF("pm-"+idx,"pass-"+idx,"Ingresa la contrasena","e");ok=false;bad=true;}\n' +
'    b.classList.toggle("bad",!ok);\n' +
'    if(ok)list.push({idx:idx,code:code,password:pass});\n' +
'  }\n' +
'  if(bad){SE("Corrige los campos en rojo.");return;}\n' +
'  btn.disabled=true;btn.innerHTML=\'<span class="spin"></span>Verificando...\';\n' +
'  fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:list[0].password})})\n' +
'  .then(function(r){return r.json();})\n' +
'  .then(function(d){\n' +
'    if(d.error){\n' +
'      SE(d.error);\n' +
'      btn.disabled=false;btn.innerHTML="Acceder al panel";return;\n' +
'    }\n' +
'    localStorage.setItem("gl_saved_devices",JSON.stringify(list));\n' +
'    document.getElementById("okBox").classList.add("on");\n' +
'    setTimeout(function(){location.replace("/dashboard");},800);\n' +
'  }).catch(function(e){SE("Error: "+e.message);btn.disabled=false;btn.innerHTML="Acceder al panel";});\n' +
'}\n' +
'</script>\n' +
'</body>\n' +
'</html>';

// ─── HTML DASHBOARD ───────────────────────────────────────────────────────────
const HTML_DASHBOARD = '<!DOCTYPE html>\n' +
'<html lang="es">\n' +
'<head>\n' +
'<meta charset="UTF-8">\n' +
'<meta name="viewport" content="width=device-width,initial-scale=1">\n' +
'<title>Panel GuardianLink</title>\n' +
'<link rel="icon" type="image/png" href="/icon.png">\n' +
'<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">\n' +
'<style>\n' +
'*{box-sizing:border-box;margin:0;padding:0}\n' +
'body{font-family:\'Inter\',sans-serif;background:#050505;color:#f1f5f9;min-height:100vh;overflow-x:hidden}\n' +
'.top{display:flex;align-items:center;justify-content:space-between;padding:16px 24px;background:#0a0a0a;border-bottom:1px solid #1a1a1a;position:sticky;top:0;z-index:100;box-shadow:0 4px 20px rgba(0,0,0,.5)}\n' +
'.brand{display:flex;align-items:center;gap:12px}\n' +
'.brand svg{width:32px;height:32px;fill:#00ff41;filter:drop-shadow(0 0 8px #00ff4160)}\n' +
'.brand h2{font-size:1.1rem;font-weight:700;letter-spacing:-.02em}\n' +
'.obadge{background:#003300;color:#00ff41;padding:4px 12px;border-radius:20px;font-size:.7rem;font-weight:700;border:1px solid #00ff4140;font-family:monospace}\n' +
'.btns{display:flex;gap:10px}\n' +
'.btn{background:#111;border:1px solid #222;color:#f1f5f9;padding:8px 16px;border-radius:8px;font-size:.85rem;font-weight:600;cursor:pointer;transition:all .2s}\n' +
'.btn:hover{background:#1a1a1a;border-color:#333}\n' +
'.btn.add{background:#00ff41;color:#000;border:none}\n' +
'.btn.add:hover{background:#00e639}\n' +
'.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:24px;padding:24px}\n' +
'.card{background:#0d0d0d;border:1px solid #1a1a1a;border-radius:16px;overflow:hidden;transition:all .3s;position:relative;display:flex;flex-direction:column}\n' +
'.card.online{border-color:#00ff4130;box-shadow:0 10px 30px rgba(0,255,65,.05)}\n' +
'.card.offline{opacity:.7;filter:grayscale(.5)}\n' +
'.cam-box{width:100%;aspect-ratio:16/9;background:#000;position:relative;display:flex;align-items:center;justify-content:center;overflow:hidden}\n' +
'canvas{width:100%;height:100%;object-fit:contain;display:none}\n' +
'.cam-ov{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:#333;z-index:10}\n' +
'.cam-ov svg{width:48px;height:48px;fill:currentColor}\n' +
'.cam-ov span{font-size:.75rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em}\n' +
'.rbadge{position:absolute;top:12px;left:12px;padding:4px 10px;border-radius:6px;font-size:.65rem;font-weight:800;font-family:monospace;z-index:20}\n' +
'.rbadge.live{background:rgba(255,0,0,.85);color:#fff;animation:pulse 1.5s infinite}\n' +
'.rbadge.off{background:rgba(0,0,0,.7);color:#555}\n' +
'@keyframes pulse{0%{opacity:1}50%{opacity:.5}100%{opacity:1}}\n' +
'.chlbl{position:absolute;top:12px;right:12px;background:rgba(0,0,0,.6);color:#888;padding:4px 8px;border-radius:6px;font-size:.65rem;font-weight:700;font-family:monospace;z-index:20}\n' +
'.tslbl{position:absolute;bottom:12px;right:12px;color:rgba(255,255,255,.4);font-size:.65rem;font-family:monospace;z-index:20}\n' +
'.osd{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;background:linear-gradient(to bottom,#111,#0a0a0a);border-bottom:1px solid #1a1a1a}\n' +
'.bwrap{display:flex;align-items:center;gap:8px}\n' +
'.bshell{width:24px;height:12px;border:1.5px solid #333;border-radius:3px;position:relative;padding:1px}\n' +
'.bshell::after{content:\'\';position:absolute;right:-3px;top:3px;width:2px;height:4px;background:#333;border-radius:0 1px 1px 0}\n' +
'.bfill{height:100%;background:#00ff41;border-radius:1px;transition:width .5s}\n' +
'.bwrap.mid .bfill{background:#f97316}\n' +
'.bwrap.low .bfill{background:#ef4444}\n' +
'.bpct{font-size:.7rem;font-weight:700;color:#555;font-family:monospace}\n' +
'.bchg{color:#00ff41;font-size:.7rem}\n' +
'.osep{width:1px;height:14px;background:#1a1a1a}\n' +
'.lwrap{display:flex;align-items:center;gap:6px;font-family:monospace}\n' +
'.ldot{width:6px;height:6px;background:#00ff41;border-radius:50%}\n' +
'.lwrap.mid .ldot{background:#f97316}\n' +
'.lwrap.bad .ldot{background:#ef4444}\n' +
'.lval{font-size:.7rem;color:#555}\n' +
'.sval{font-size:.7rem;color:#444;font-family:monospace}\n' +
'.istrip{padding:14px 16px;display:flex;flex-direction:column;gap:4px}\n' +
'.irow{display:flex;justify-content:space-between;align-items:center}\n' +
'.ilbl{font-size:.65rem;color:#444;text-transform:uppercase;font-weight:700;letter-spacing:.05em}\n' +
'.ival{font-size:.75rem;color:#aaa;font-weight:600}\n' +
'.ival.g{color:#00ff41;font-family:monospace}\n' +
'.ctrls{display:grid;grid-template-columns:1fr 1fr 1fr;gap:1px;background:#1a1a1a;border-top:1px solid #1a1a1a;border-bottom:1px solid #1a1a1a}\n' +
'.cb{background:#0d0d0d;border:none;color:#555;padding:12px 8px;font-size:.7rem;font-weight:700;cursor:pointer;transition:all .15s;display:flex;flex-direction:column;align-items:center;gap:4px}\n' +
'.cb:hover{background:#151515;color:#f1f5f9}\n' +
'.cb.on{color:#00ff41;background:#001a00}\n' +
'.cb.fon{color:#fbbf24;background:#1a1500}\n' +
'.cb.espyon{color:#f97316;background:#1a0f00}\n' +
'.cb.filtron{color:#8b5cf6;background:#10001a}\n' +
'.cb.rm:hover{background:#1a0000;color:#ef4444}\n' +
'.ctrls2{display:grid;grid-template-columns:1fr 1fr 1fr;gap:1px;background:#1a1a1a}\n' +
'.espy-wrap{display:none;padding:12px 16px;background:#0a0a0a;align-items:center;gap:12px;border-top:1px solid #1a1a1a}\n' +
'.espy-wrap.on{display:flex}\n' +
'.espy-lbl{font-size:.8rem;color:#f97316}\n' +
'.espy-bar{flex:1;height:4px;appearance:none;background:#333;border-radius:2px;outline:none}\n' +
'.espy-bar::-webkit-slider-thumb{appearance:none;width:14px;height:14px;background:#f97316;border-radius:50%;cursor:pointer}\n' +
'.espy-val{font-size:.7rem;color:#f97316;font-family:monospace;width:24px;text-align:right}\n' +
'.fwrap{position:relative}\n' +
'.fmenu{position:absolute;bottom:100%;left:0;right:0;background:#111;border:1px solid #222;border-radius:10px 10px 0 0;padding:6px;display:none;flex-direction:column;gap:2px;z-index:50;box-shadow:0 -10px 30px rgba(0,0,0,.8)}\n' +
'.fmenu.on{display:flex}\n' +
'.fitem{display:flex;align-items:center;gap:10px;padding:10px;border-radius:6px;font-size:.75rem;color:#aaa;cursor:pointer}\n' +
'.fitem:hover{background:#1a1a1a;color:#fff}\n' +
'.fitem.active{background:#00ff4115;color:#00ff41}\n' +
'.fp{width:16px;height:16px;border-radius:4px;border:1px solid #333}\n' +
'.ai{position:absolute;bottom:0;left:0;right:0;height:40px;display:none;align-items:flex-end;justify-content:center;gap:3px;padding-bottom:8px;background:linear-gradient(to top,rgba(0,255,65,.15),transparent);z-index:15}\n' +
'.ai.on{display:flex}\n' +
'.ab{width:3px;height:10px;background:#00ff41;border-radius:2px;animation:wave 1s infinite}\n' +
'.ab:nth-child(2){animation-delay:.1s;height:18px}\n' +
'.ab:nth-child(3){animation-delay:.2s;height:24px}\n' +
'.ab:nth-child(4){animation-delay:.3s;height:16px}\n' +
'.ab:nth-child(5){animation-delay:.4s;height:12px}\n' +
'@keyframes wave{0%,100%{transform:scaleY(1)}50%{transform:scaleY(.4)}}\n' +
'#empty{height:60vh;display:none;flex-direction:column;align-items:center;justify-content:center;color:#222;gap:16px}\n' +
'#empty svg{width:80px;height:80px;fill:currentColor}\n' +
'#empty p{font-size:.9rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em}\n' +
'#mbg{position:fixed;inset:0;background:rgba(0,0,0,.85);backdrop-filter:blur(6px);display:none;align-items:center;justify-content:center;z-index:200;padding:20px}\n' +
'#mbg.on{display:flex}\n' +
'.mcard{background:#111;border:1px solid #222;border-radius:20px;width:100%;max-width:400px;padding:30px;box-shadow:0 30px 100px rgba(0,0,0,.9)}\n' +
'.mcard h3{margin-bottom:4px;font-size:1.2rem}\n' +
'.mcard .msub{color:#444;font-size:.75rem;margin-bottom:24px}\n' +
'.mfg{margin-bottom:16px;display:flex;flex-direction:column;gap:6px}\n' +
'.mlbl{font-size:.65rem;color:#555;font-weight:700;text-transform:uppercase;letter-spacing:.1em}\n' +
'.mi{background:#080808;border:1.5px solid #222;border-radius:8px;padding:12px;color:#fff;font-family:monospace;outline:none;transition:border-color .2s}\n' +
'.mi:focus{border-color:#00ff41}\n' +
'.mi.bad{border-color:#ef4444}\n' +
'.mfm{font-size:.65rem;font-family:monospace;min-height:14px}\n' +
'.mfm.e{color:#ef4444}.mfm.o{color:#00ff41}.mfm.w{color:#f97316}\n' +
'.mbtns{display:grid;grid-template-columns:1fr 1.5fr;gap:12px;margin-top:24px}\n' +
'#toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(100px);background:#111;color:#fff;padding:12px 24px;border-radius:12px;font-size:.85rem;font-weight:600;border:1px solid #222;box-shadow:0 10px 30px rgba(0,0,0,.5);transition:transform .3s cubic-bezier(.18,.89,.32,1.28);z-index:300;display:flex;align-items:center;gap:10px}\n' +
'#toast.on{transform:translateX(-50%) translateY(0)}\n' +
'#toast::before{content:\'\\2022\';color:#00ff41;font-size:1.5rem}\n' +
'</style>\n' +
'</head>\n' +
'<body>\n' +
'<div class="top">\n' +
'  <div class="brand">\n' +
'    <svg viewBox="0 0 24 24"><path d="M12,1L3,5v6c0,5.55,3.84,10.74,9,12,5.16-1.26,9-6.45,9-12V5L12,1zm-2,16-4-4,1.41-1.41L10,14.17l6.59-6.59L18,9l-8,8z"/></svg>\n' +
'    <div>\n' +
'      <h2>GuardianLink</h2>\n' +
'      <div class="obadge" id="obadge">0/0 EN L&Iacute;NEA</div>\n' +
'    </div>\n' +
'  </div>\n' +
'  <div class="btns">\n' +
'    <button class="btn add" onclick="openModal()">+ Agregar dispositivo</button>\n' +
'    <button class="btn" onclick="LO()">Cerrar sesi&oacute;n</button>\n' +
'  </div>\n' +
'</div>\n' +
'<div id="empty">\n' +
'  <svg viewBox="0 0 24 24"><path d="M12,1L3,5v6c0,5.55,3.84,10.74,9,12,5.16-1.26,9-6.45,9-12V5L12,1z M12,17c-2.76,0-5-2.24-5-5s2.24-5,5-5s5,2.24,5,5S14.76,17,12,17z"/></svg>\n' +
'  <p>No hay dispositivos configurados</p>\n' +
'</div>\n' +
'<div class="grid" id="grid"></div>\n' +
'<div id="mbg" onclick="bgClose(event)">\n' +
'  <div class="mcard">\n' +
'    <h3 id="mnum">Dispositivo #1</h3>\n' +
'    <p class="msub">Ingresa las credenciales del tel&eacute;fono</p>\n' +
'    <div class="mfg">\n' +
'      <span class="mlbl">C&oacute;digo del tel&eacute;fono</span>\n' +
'      <input type="text" id="mcode" class="mi" placeholder="AAA-BBB-CCC" maxlength="11" oninput="mFC()" onblur="mCK()">\n' +
'      <div class="mfm" id="mcodemsg"></div>\n' +
'    </div>\n' +
'    <div class="mfg">\n' +
'      <span class="mlbl">Contrase&ntilde;a</span>\n' +
'      <input type="password" id="mpass" class="mi" placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;" oninput="mSF(&#39;mpassmsg&#39;,&#39;mpass&#39;,&#39;&#39;,&#39;&#39;)" onblur="mVP()">\n' +
'      <div class="mfm" id="mpassmsg"></div>\n' +
'    </div>\n' +
'    <div class="mbtns">\n' +
'      <button class="btn" onclick="closeModal()">Cancelar</button>\n' +
'      <button class="btn add" id="mokbtn" onclick="mAdd()">Conectar dispositivo</button>\n' +
'    </div>\n' +
'  </div>\n' +
'</div>\n' +
'<div id="toast"></div>\n' +
'<script>\n' +
'var DV=[],ST={},WS={},TK="";\n' +
'function init(){\n' +
'  var m=(document.cookie||\'\').match(/(?:^|;\\s*)gl_session=([^;]+)/);\n' +
'  TK=m?m[1]:"";\n' +
'  if(!TK)location.replace("/login");\n' +
'  \n' +
'  // CARGAR DISPOSITIVOS GUARDADOS PERMANENTEMENTE\n' +
'  var saved=localStorage.getItem("gl_saved_devices");\n' +
'  if(saved){DV=JSON.parse(saved);}\n' +
'  \n' +
'  if(DV.length){\n' +
'    document.getElementById("grid").style.display="grid";\n' +
'    document.getElementById("empty").style.display="none";\n' +
'    DV.forEach(function(d,i){mkCard(d.code,i+1,d.label);wsConn(d.code,d.password);});\n' +
'    updBadge();\n' +
'  }else{document.getElementById("empty").style.display="flex";}\n' +
'  \n' +
'  setInterval(function(){Object.keys(ST).forEach(updLat);},2000);\n' +
'  setInterval(function(){Object.keys(ST).forEach(doPing);},10000);\n' +
'  setInterval(function(){\n' +
'    Object.keys(ST).forEach(function(code){\n' +
'      var s=ST[code];\n' +
'      if(s.lastFrame && (Date.now()-s.lastFrame > 5000)){\n' +
'        setOnline(code,false);updBadge();\n' +
'      }\n' +
'    });\n' +
'  },2000);\n' +
'}\n' +
'function sCmd(code,action,params){\n' +
'  return fetch("/api/command/"+code,{method:"POST",headers:{"Content-Type":"application/json","x-session-token":TK},body:JSON.stringify({action:action,params:params||{}})});\n' +
'}\n' +
'function mkCard(code,ch,label){\n' +
'  ST[code]={code:code,label:label,online:false,lastFrame:null,rendering:false,filter:"none",battery:0,charging:false,lastLat:null,pingSent:null,bin:0,audio:false,actx:null,gainNode:null,nextPlay:0,flash:false,earspy:false,gain:1};\n' +
'  var g=document.getElementById("grid");\n' +
'  var el=document.createElement("div");el.className="card offline";el.id="card-"+code;\n' +
'  el.innerHTML=\'<div class="cam-box">\'+\n' +
'    \'<canvas id="cv-\'+code+\'"></canvas>\'+\n' +
'    \'<div class="cam-ov" id="ov-\'+code+\'"><svg viewBox="0 0 24 24"><path d="M17,10.5V7a1,1,0,0,0-1-1H4A1,1,0,0,0,3,7V17a1,1,0,0,0,1,1H16a1,1,0,0,0,1-1V13.5l4,4V6.5Z"/></svg><span>Esperando...</span></div>\'+\n' +
'    \'<div class="rbadge off" id="rec-\'+code+\'">OFFLINE</div>\'+\n' +
'    \'<div class="chlbl">CAM \'+ch+\'</div>\'+\n' +
'    \'<div class="tslbl" id="ts-\'+code+\'"></div>\'+\n' +
'    \'<div class="ai" id="ai-\'+code+\'"><div class="ab" style="height:40%"></div><div class="ab"></div><div class="ab"></div><div class="ab"></div><div class="ab" style="height:40%"></div></div>\'+\n' +
'    \'</div>\'+\n' +
'    \'<div class="osd">\'+\n' +
'    \'<div class="bwrap" id="bat-\'+code+\'">\'+\n' +
'    \'<div class="bshell"><div class="bfill" id="batf-\'+code+\'" style="width:0%"></div></div>\'+\n' +
'    \'<span class="bpct" id="batp-\'+code+\'">--%</span>\'+\n' +
'    \'<span class="bchg" id="batc-\'+code+\'" style="display:none">&#9889;</span>\'+\n' +
'    \'</div>\'+\n' +
'    \'<div class="osep"></div>\'+\n' +
'    \'<div class="lwrap" id="lat-\'+code+\'"><span class="ldot"></span><span class="lval" id="latv-\'+code+\'">-- ms</span></div>\'+\n' +
'    \'<span class="sval" id="spd-\'+code+\'">-- KB/s</span>\'+\n' +
'    \'</div>\'+\n' +
'    \'<div class="istrip">\'+\n' +
'    \'<div class="irow"><span class="ilbl">Tel&eacute;fono</span><span class="ival" id="phn-\'+code+\'">-</span></div>\'+\n' +
'    \'<div class="irow"><span class="ilbl">C&oacute;digo</span><span class="ival g">\'+code+\'</span></div>\'+\n' +
'    \'<div class="irow"><span class="ilbl">Conectado</span><span class="ival" id="cdt-\'+code+\'">-</span></div>\'+\n' +
'    \'</div>\'+\n' +
'    \'<div class="ctrls">\'+\n' +
'    \'<button class="cb" id="bf-\'+code+\'" onclick="tF(&#39;\'+code+\'&#39;,this)">&#128161; Flash</button>\'+\n' +
'    \'<button class="cb" id="ba-\'+code+\'" onclick="tA(&#39;\'+code+\'&#39;,this)">&#127908; Audio</button>\'+\n' +
'    \'<button class="cb" id="bes-\'+code+\'" onclick="tEspy(&#39;\'+code+\'&#39;,this)" title="Ear Spy - amplifica el microfono">&#128565; Ear Spy</button>\'+\n' +
'    \'</div>\'+\n' +
'    \'<div class="espy-wrap" id="espy-\'+code+\'">\'+\n' +
'    \'<span class="espy-lbl">&#128266;</span>\'+\n' +
'    \'<input class="espy-bar" id="egain-\'+code+\'" type="range" min="1" max="10" step="0.5" value="1" oninput="updGain(&#39;\'+code+\'&#39;,this.value)">\'+\n' +
'    \'<span class="espy-val" id="egainv-\'+code+\'">1x</span>\'+\n' +
'    \'</div>\'+\n' +
'    \'<div class="ctrls2" style="grid-template-columns:1fr 1fr 1fr">\'+\n' +
'    \'<button class="cb on" id="bc-\'+code+\'" onclick="tCam(&#39;\'+code+\'&#39;,this)">&#128247; Trasera</button>\'+\n' +
'    \'<button class="cb" onclick="sCmd(&#39;\'+code+\'&#39;,&#39;snapshot&#39;)">&#128248; Foto</button>\'+\n' +
'    \'<div class="fwrap" id="fwrap-\'+code+\'">\'+\n' +
'    \'<div class="fmenu" id="fmenu-\'+code+\'">\'+\n' +
'    \'<div class="fitem active" data-f="none" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;none&#39;,this)"><span class="fp" style="background:#555"></span>Normal</div>\'+\n' +
'    \'<div class="fitem" data-f="night" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;night&#39;,this)"><span class="fp" style="background:linear-gradient(#001a00,#003300)"></span>Noche</div>\'+\n' +
'    \'<div class="fitem" data-f="sharp" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;sharp&#39;,this)"><span class="fp" style="background:linear-gradient(#000,#fff)"></span>Nitidez</div>\'+\n' +
'    \'<div class="fitem" data-f="nvg" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;nvg&#39;,this)"><span class="fp" style="background:linear-gradient(#003300,#00ff41)"></span>NVG Verde</div>\'+\n' +
'    \'<div class="fitem" data-f="thermal" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;thermal&#39;,this)"><span class="fp" style="background:linear-gradient(#00f,#f00)"></span>T&eacute;rmico</div>\'+\n' +
'    \'<div class="fitem" data-f="sepia" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;sepia&#39;,this)"><span class="fp" style="background:linear-gradient(#3d2b00,#c8a000)"></span>C&aacute;lido</div>\'+\n' +
'    \'<div class="fitem" data-f="invert" onclick="setFilter(&#39;\'+code+\'&#39;,&#39;invert&#39;,this)"><span class="fp" style="background:linear-gradient(#fff,#000)"></span>Invertir</div>\'+\n' +
'    \'</div>\'+\n' +
'    \'<button class="cb" id="bfilt-\'+code+\'" onclick="toggleFMenu(&#39;\'+code+\'&#39;,this)">&#127912; Filtro</button>\n' +
'    \'</div>\'+\n' +
'    \'<button class="cb rm" onclick="rmCard(&#39;\'+code+\'&#39;)">&#10005; Quitar</button>\n' +
'    \'</div>\';\n' +
'  g.appendChild(el);\n' +
'}\n' +
'function wsConn(code,pw){\n' +
'  var pr=location.protocol==="https:"?"wss:":"ws:";\n' +
'  var url=pr+"//"+location.host+"/ws?code="+encodeURIComponent(code)+"&token="+encodeURIComponent(TK)+"&role=viewer";\n' +
'  var ws=new WebSocket(url);WS[code]=ws;ws.binaryType="arraybuffer";\n' +
'  ws.onopen=function(){\n' +
'    var s=ST[code];if(s){s.connDate=new Date().toLocaleString("es-ES",{hour12:false});}\n' +
'    var e=document.getElementById("cdt-"+code);if(e&&ST[code])e.textContent=ST[code].connDate;\n' +
'    setOnline(code,true);updBadge();\n' +
'    toast("Conectado: "+code);\n' +
'  };\n' +
'  ws.onclose=function(){\n' +
'    setOnline(code,false);stopAudio(code);updBadge();\n' +
'    setTimeout(function(){var d=DV.filter(function(x){return x.code===code;})[0];if(d)wsConn(d.code,d.password);},4000);\n' +
'  };\n' +
'  ws.onerror=function(){setOnline(code,false);updBadge();};\n' +
'  ws.onmessage=function(e){onMsg(code,e);};\n' +
'}\n' +
'function onMsg(code,evt){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  if(typeof evt.data==="string"){\n' +
'    try{\n' +
'      var m=JSON.parse(evt.data);\n' +
'      if(m.type==="device_info"){var e=document.getElementById("phn-"+code);if(e&&m.label)e.textContent=m.label;setOnline(code,true);updBadge();}\n' +
'      if(m.type==="pong"&&s.pingSent){var ms=Date.now()-s.pingSent;s.lastLat=ms;setLat(code,ms);}\n' +
'      if(m.type==="device_status"){updBat(code,m.battery,m.charging);setOnline(code,true);if(m.phone_number){var pe=document.getElementById("phn-"+code);if(pe)pe.textContent=m.phone_number;}}\n' +
'      if(m.type==="audio_chunk"&&s.audio){playAudio(code,m.data);s.bin+=(m.data?m.data.length*.75:0);}\n' +
'      if(m.type==="device_offline"){setOnline(code,false);updBadge();}\n' +
'    }catch(x){}\n' +
'  }else{\n' +
'    s.bin+=evt.data.byteLength;\n' +
'    renderFrame(code,evt.data);\n' +
'    setOnline(code,true);\n' +
'    var t=document.getElementById("ts-"+code);if(t)t.textContent=new Date().toLocaleTimeString("es-ES",{hour12:false});\n' +
'  }\n' +
'}\n' +
'function renderFrame(code,buf){\n' +
'  var cv=document.getElementById("cv-"+code);if(!cv)return;\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.lastFrame=Date.now();\n' +
'  if(s.rendering)return;\n' +
'  s.rendering=true;\n' +
'  cv.style.display="block";\n' +
'  var ov=document.getElementById("ov-"+code);if(ov)ov.style.display="none";\n' +
'  var blob=new Blob([buf],{type:"image/jpeg"});\n' +
'  createImageBitmap(blob).then(function(bitmap){\n' +
'    if(cv.width!==bitmap.width||cv.height!==bitmap.height){cv.width=bitmap.width;cv.height=bitmap.height;}\n' +
'    var ctx=cv.getContext("2d");\n' +
'    var f=s?s.filter:"none";\n' +
'    var FILTERS={\n' +
'      none:"none",\n' +
'      night:"brightness(2.5) contrast(1.8) saturate(0.3)",\n' +
'      sharp:"contrast(2.2) brightness(1.1) saturate(1.2)",\n' +
'      nvg:"brightness(1.8) contrast(1.6) saturate(0) sepia(1) hue-rotate(90deg) brightness(1.4)",\n' +
'      thermal:"contrast(1.4) saturate(3) hue-rotate(200deg) brightness(1.2)",\n' +
'      sepia:"sepia(0.9) brightness(1.15) contrast(1.1)",\n' +
'      invert:"invert(1) hue-rotate(180deg)"\n' +
'    };\n' +
'    ctx.filter=FILTERS[f]||"none";\n' +
'    ctx.drawImage(bitmap,0,0);\n' +
'    ctx.filter="none";\n' +
'    bitmap.close();\n' +
'    s.rendering=false;\n' +
'  }).catch(function(){s.rendering=false;});\n' +
'}\n' +
'var FILTER_LABELS={none:"&#127912; Filtro",night:"&#127912; Noche",sharp:"&#127912; Nitidez",nvg:"&#127912; NVG",thermal:"&#127912; T&eacute;rmico",sepia:"&#127912; C&aacute;lido",invert:"&#127912; Invertir"};\n' +
'function toggleFMenu(code,btn){\n' +
'  var m=document.getElementById("fmenu-"+code);if(!m)return;\n' +
'  var open=m.classList.toggle("on");\n' +
'  btn.classList.toggle("filtron",open);\n' +
'  if(open){\n' +
'    Object.keys(ST).forEach(function(c){\n' +
'      if(c!==code){var o=document.getElementById("fmenu-"+c);if(o)o.classList.remove("on");var b=document.getElementById("bfilt-"+c);if(b)b.classList.remove("filtron");}\n' +
'    });\n' +
'    setTimeout(function(){\n' +
'      document.addEventListener("click",function handler(e){\n' +
'        var w=document.getElementById("fwrap-"+code);\n' +
'        if(w&&!w.contains(e.target)){m.classList.remove("on");btn.classList.remove("filtron");document.removeEventListener("click",handler);}\n' +
'      });\n' +
'    },50);\n' +
'  }\n' +
'}\n' +
'function setFilter(code,fname,item){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.filter=fname;\n' +
'  var m=document.getElementById("fmenu-"+code);\n' +
'  if(m){var items=m.querySelectorAll(".fitem");items.forEach(function(it){it.classList.toggle("active",it.dataset.f===fname);});}\n' +
'  var btn=document.getElementById("bfilt-"+code);\n' +
'  if(btn){btn.innerHTML=FILTER_LABELS[fname]||"&#127912; Filtro";btn.classList.toggle("filtron",fname!=="none");}\n' +
'  if(m)m.classList.remove("on");\n' +
'  toast("Filtro: "+(fname==="none"?"Normal":fname)+" \u00b7 "+code);\n' +
'}\n' +
'function updBat(code,pct,chg){\n' +
'  var s=ST[code];if(!s)return;s.battery=pct;s.charging=!!chg;\n' +
'  var w=document.getElementById("bat-"+code),f=document.getElementById("batf-"+code),t=document.getElementById("batp-"+code),ic=document.getElementById("batc-"+code);\n' +
'  if(!w||!f||!t)return;\n' +
'  var p=Math.max(0,Math.min(100,parseInt(pct,10)||0));\n' +
'  f.style.width=p+"%";t.textContent=p+"%";if(ic)ic.style.display=chg?"inline":"none";\n' +
'  w.classList.remove("mid","low");if(p<=20)w.classList.add("low");else if(p<=45)w.classList.add("mid");\n' +
'}\n' +
'function setLat(code,ms){\n' +
'  var w=document.getElementById("lat-"+code),v=document.getElementById("latv-"+code);if(!v)return;\n' +
'  v.textContent=ms+" ms";if(w){w.classList.remove("mid","bad");if(ms>200)w.classList.add("bad");else if(ms>100)w.classList.add("mid");}\n' +
'}\n' +
'function updLat(code){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  if(s.lastLat!==null){setLat(code,s.lastLat);return;}\n' +
'  if(s.lastFrame){var age=Date.now()-s.lastFrame;if(age<8000)setLat(code,age);}\n' +
'}\n' +
'function doPing(code){\n' +
'  var s=ST[code],ws=WS[code];\n' +
'  if(!s||!ws||ws.readyState!==WebSocket.OPEN)return;\n' +
'  s.pingSent=Date.now();\n' +
'  ws.send(JSON.stringify({type:"ping"}));\n' +
'}\n' +
'function setOnline(code,on){\n' +
'  var card=document.getElementById("card-"+code),rec=document.getElementById("rec-"+code),ov=document.getElementById("ov-"+code);\n' +
'  if(card){card.classList.toggle("online",on);card.classList.toggle("offline",!on);}\n' +
'  if(rec){rec.textContent=on?"● REC":"OFFLINE";rec.className="rbadge "+(on?"live":"off");}\n' +
'  if(!on&&ov){ov.style.display="flex";var cv=document.getElementById("cv-"+code);if(cv)cv.style.display="none";}\n' +
'}\n' +
'function updBadge(){\n' +
'  var total=DV.length;\n' +
'  var online=Object.keys(ST).filter(function(c){var r=document.getElementById("rec-"+c);return r&&r.classList.contains("live");}).length;\n' +
'  var e=document.getElementById("obadge");if(e)e.textContent=online+"/"+total+" EN L\\u00CDNEA";\n' +
'}\n' +
'function tF(code,btn){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.flash=!s.flash;\n' +
'  btn.classList.toggle("fon",s.flash);\n' +
'  btn.innerHTML=s.flash?"&#128161; ON":"&#128161; Flash";\n' +
'  sCmd(code,s.flash?"flash_on":"flash_off");\n' +
'  toast("Flash "+(s.flash?"ON":"OFF")+" "+code);\n' +
'}\n' +
'function tA(code,btn){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.audio=!s.audio;\n' +
'  if(s.audio) ensureActx(code);\n' +
'  btn.classList.toggle("on",s.audio);\n' +
'  btn.innerHTML=s.audio?"&#127908; Silenciar":"&#127908; Audio";\n' +
'  var ai=document.getElementById("ai-"+code);if(ai)ai.classList.toggle("on",s.audio);\n' +
'  sCmd(code,s.audio?"start_audio":"stop_audio");\n' +
'}\n' +
'function tEspy(code,btn){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.earspy=!s.earspy;\n' +
'  btn.classList.toggle("espyon",s.earspy);\n' +
'  btn.innerHTML=s.earspy?"&#128565; ON":"&#128565; Ear Spy";\n' +
'  var wrap=document.getElementById("espy-"+code);if(wrap)wrap.classList.toggle("on",s.earspy);\n' +
'  if(s.earspy&&!s.audio){\n' +
'    s.audio=true;\n' +
'    var ab=document.getElementById("ba-"+code);\n' +
'    if(ab){ab.classList.add("on");ab.innerHTML="&#127908; Silenciar";}\n' +
'    var ai=document.getElementById("ai-"+code);if(ai)ai.classList.add("on");\n' +
'    sCmd(code,"start_audio");\n' +
'  }\n' +
'  if(s.earspy) ensureActx(code);\n' +
'  var g=s.earspy?s.gain:1;\n' +
'  if(s.gainNode)s.gainNode.gain.setTargetAtTime(g,s.actx.currentTime,0.05);\n' +
'  toast("Ear Spy "+(s.earspy?"ON x"+s.gain:"OFF")+" \u00b7 "+code);\n' +
'}\n' +
'function updGain(code,val){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.gain=parseFloat(val);\n' +
'  var lbl=document.getElementById("egainv-"+code);if(lbl)lbl.textContent=s.gain+"x";\n' +
'  var bar=document.getElementById("egain-"+code);\n' +
'  if(bar){var pct=((s.gain-1)/9)*100;bar.style.background="linear-gradient(to right,#f97316 "+pct+"%,#333 "+pct+")";}\n' +
'  if(s.gainNode&&s.earspy)s.gainNode.gain.setTargetAtTime(s.gain,s.actx.currentTime,0.05);\n' +
'}\n' +
'function ensureActx(code){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  if(!s.actx||s.actx.state==="closed"){\n' +
'    s.actx=new(window.AudioContext||window.webkitAudioContext)({sampleRate:16000});\n' +
'    s.gainNode=s.actx.createGain();\n' +
'    s.gainNode.gain.value=1;\n' +
'    s.gainNode.connect(s.actx.destination);\n' +
'    s.nextPlay=s.actx.currentTime;\n' +
'  }\n' +
'  if(s.actx.state==="suspended")s.actx.resume();\n' +
'}\n' +
'function tCam(code,btn){\n' +
'  btn.classList.add("on");btn.innerHTML="&#128247; Trasera";\n' +
'  sCmd(code,"camera_rear");\n' +
'}\n' +
'function playAudio(code,base64){\n' +
'  var s=ST[code];if(!s||!s.audio||!s.actx)return;\n' +
'  var bin=atob(base64),len=bin.length,buf=new Int16Array(len/2);\n' +
'  for(var i=0;i<len;i+=2)buf[i/2]=(bin.charCodeAt(i+1)<<8)|bin.charCodeAt(i);\n' +
'  var fbuf=s.actx.createBuffer(1,buf.length,16000),chan=fbuf.getChannelData(0);\n' +
'  for(var i=0;i<buf.length;i++)chan[i]=buf[i]/32768;\n' +
'  var src=s.actx.createBufferSource();src.buffer=fbuf;\n' +
'  src.connect(s.gainNode);\n' +
'  var start=Math.max(s.actx.currentTime,s.nextPlay);\n' +
'  src.start(start);s.nextPlay=start+fbuf.duration;\n' +
'}\n' +
'function stopAudio(code){\n' +
'  var s=ST[code];if(!s)return;\n' +
'  s.audio=false;if(s.actx)s.actx.suspend();\n' +
'  var b=document.getElementById("ba-"+code);if(b){b.classList.remove("on");b.innerHTML="&#127908; Audio";}\n' +
'  var ai=document.getElementById("ai-"+code);if(ai)ai.classList.remove("on");\n' +
'}\n' +
'function rmCard(code){\n' +
'  if(!confirm("¿Quitar dispositivo "+code+"?"))return;\n' +
'  if(WS[code]){WS[code].close();delete WS[code];}\n' +
'  delete ST[code];\n' +
'  DV=DV.filter(function(d){return d.code!==code;});\n' +
'  localStorage.setItem("gl_saved_devices",JSON.stringify(DV));\n' +
'  var card=document.getElementById("card-"+code);if(card)card.remove();\n' +
'  updBadge();\n' +
'  if(!DV.length){document.getElementById("grid").style.display="none";document.getElementById("empty").style.display="flex";}\n' +
'}\n' +
'var mCTimer=null;\n' +
'function openModal(){\n' +
'  document.getElementById("mnum").textContent="Dispositivo #"+(DV.length+1);\n' +
'  document.getElementById("mcode").value="";\n' +
'  document.getElementById("mpass").value="";\n' +
'  document.getElementById("mcodemsg").textContent="";\n' +
'  document.getElementById("mpassmsg").textContent="";\n' +
'  document.getElementById("mcode").className="mi";\n' +
'  document.getElementById("mpass").className="mi";\n' +
'  document.getElementById("mokbtn").disabled=false;\n' +
'  document.getElementById("mokbtn").textContent="Conectar dispositivo";\n' +
'  document.getElementById("mbg").classList.add("on");\n' +
'  setTimeout(function(){document.getElementById("mcode").focus();},100);\n' +
'}\n' +
'function closeModal(){document.getElementById("mbg").classList.remove("on");}\n' +
'function bgClose(e){if(e.target===document.getElementById("mbg"))closeModal();}\n' +
'function mFC(){\n' +
'  var el=document.getElementById("mcode");\n' +
'  var raw=el.value.replace(/[^A-Za-z0-9]/g,"").toUpperCase().slice(0,9);\n' +
'  var out=raw;\n' +
'  if(raw.length>6)out=raw.slice(0,3)+"-"+raw.slice(3,6)+"-"+raw.slice(6);\n' +
'  else if(raw.length>3)out=raw.slice(0,3)+"-"+raw.slice(3);\n' +
'  el.value=out;\n' +
'  mSF("mcodemsg","mcode","","");\n' +
'  if(raw.length===9){clearTimeout(mCTimer);mCTimer=setTimeout(mCK,600);}\n' +
'}\n' +
'function mCK(){\n' +
'  var el=document.getElementById("mcode");\n' +
'  var c=el.value.trim().toUpperCase();if(!c)return;\n' +
'  if(!/^[A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{3}$/.test(c)){mSF("mcodemsg","mcode","Formato: AAA-BBB-CCC","e");return;}\n' +
'  mSF("mcodemsg","mcode","Verificando...","w");\n' +
'  fetch("/api/check-device",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:c})})\n' +
'  .then(function(r){return r.json();})\n' +
'  .then(function(d){\n' +
'    if(d.exists)mSF("mcodemsg","mcode","OK "+(d.label||"")+" "+(d.online?"[EN LINEA]":"[OFFLINE]"),"o");\n' +
'    else mSF("mcodemsg","mcode","No encontrado - abre la app","e");\n' +
'  }).catch(function(){mSF("mcodemsg","mcode","Sin conexion","w");});\n' +
'}\n' +
'function mVP(){\n' +
'  var el=document.getElementById("mpass");if(!el.value)return;\n' +
'  mSF("mpassmsg","mpass","Verificando...","w");\n' +
'  fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:el.value})})\n' +
'  .then(function(r){if(r.ok)mSF("mpassmsg","mpass","Correcta","o");else mSF("mpassmsg","mpass","Incorrecta","e");})\n' +
'  .catch(function(){mSF("mpassmsg","mpass","Sin conexion","w");});\n' +
'}\n' +
'function mSF(mid,fid,txt,cls){\n' +
'  var m=document.getElementById(mid),f=document.getElementById(fid);\n' +
'  if(m){m.textContent=txt;m.className="mfm"+(cls?" "+cls:"");}\n' +
'  if(f){f.classList.remove("bad");if(cls==="e")f.classList.add("bad");}\n' +
'}\n' +
'function mAdd(){\n' +
'  var code=document.getElementById("mcode").value.trim().toUpperCase();\n' +
'  var pass=document.getElementById("mpass").value;\n' +
'  var ok=true;\n' +
'  if(!code||!/^[A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{3}$/.test(code)){mSF("mcodemsg","mcode","Ingresa un codigo valido","e");ok=false;}\n' +
'  if(!pass){mSF("mpassmsg","mpass","Ingresa la contrasena","e");ok=false;}\n' +
'  if(!ok)return;\n' +
'  if(DV.filter(function(d){return d.code===code;}).length){mSF("mcodemsg","mcode","Ya esta en el panel","e");return;}\n' +
'  var btn=document.getElementById("mokbtn");btn.disabled=true;btn.innerHTML=\'<span class="spin"></span>Verificando...\';\n' +
'  fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:pass})})\n' +
'  .then(function(r){return r.json().then(function(d){return{r:r,d:d};});})\n' +
'  .then(function(x){\n' +
'    if(!x.r.ok){mSF("mpassmsg","mpass","Contrasena incorrecta","e");btn.disabled=false;btn.textContent="Conectar dispositivo";return;}\n' +
'    return fetch("/api/check-device",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:code})})\n' +
'    .then(function(r){return r.json();})\n' +
'    .then(function(cd){\n' +
'      if(!cd.exists){mSF("mcodemsg","mcode","No registrado - abre la app","e");btn.disabled=false;btn.textContent="Conectar dispositivo";return;}\n' +
'      var dev={code:code,password:pass,label:cd.label||code,online:cd.online||false};\n' +
'      DV.push(dev);localStorage.setItem("gl_saved_devices",JSON.stringify(DV));\n' +
'      document.getElementById("grid").style.display="grid";\n' +
'      document.getElementById("empty").style.display="none";\n' +
'      mkCard(code,DV.length,dev.label);\n' +
'      wsConn(code,pass);\n' +
'      updBadge();closeModal();toast("Dispositivo "+code+" agregado");\n' +
'    });\n' +
'  }).catch(function(e){mSF("mcodemsg","mcode","Error: "+e.message,"e");btn.disabled=false;btn.textContent="Conectar dispositivo";});\n' +
'}\n' +
'function LO(){\n' +
'  fetch("/api/logout",{method:"POST",headers:{"x-session-token":TK}}).catch(function(){});\n' +
'  sessionStorage.clear();document.cookie="gl_session=;Path=/;Max-Age=0";\n' +
'  location.replace("/login");\n' +
'}\n' +
'var toastTmr=null;\n' +
'function toast(msg){var t=document.getElementById("toast");t.textContent=msg;t.classList.add("on");clearTimeout(toastTmr);toastTmr=setTimeout(function(){t.classList.remove("on");},3000);}\n' +
'init();\n' +
'<\/script>\n' +
'</body>\n' +
'</html>';

// ─── EXPRESS ──────────────────────────────────────────────────────────────────
const app = express();

app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: false,
    directives: {
      defaultSrc:     ["'self'"],
      scriptSrc:      ["'self'", "'unsafe-inline'"],
      scriptSrcAttr:  ["'unsafe-inline'"],
      styleSrc:       ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc:        ["'self'", 'https://fonts.gstatic.com'],
      connectSrc:     ["'self'", 'wss:', 'ws:'],
      imgSrc:         ["'self'", 'data:', 'blob:'],
      mediaSrc:       ["'self'", 'blob:'],
      formAction:     ["'self'"],
      frameAncestors: ["'none'"]
    }
  },
  hsts: false
}));
app.use(morgan('combined'));
app.use(cors({ origin: false }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api/login',          rateLimit({ windowMs: 60_000, max: 20,  message: { error: 'Demasiadas peticiones' } }));
app.use('/api/register-device',rateLimit({ windowMs: 60_000, max: 30,  message: { error: 'Demasiadas peticiones' } }));
app.use('/api/',               rateLimit({ windowMs: 60_000, max: 200, message: { error: 'Demasiadas peticiones' } }));

app.get('/icon.png', function(req, res) {
  res.sendFile(path.join(__dirname, 'icon.png'));
});

app.get('/', function(req, res) { res.redirect('/login'); });
app.get('/login', function(req, res) { res.send(HTML_LOGIN); });
app.get('/dashboard', requireCookie, function(req, res) { res.send(HTML_DASHBOARD); });

app.use(express.static('public'));

// ─── API ──────────────────────────────────────────────────────────────────────
app.post('/api/login', function(req, res) {
  const password = req.body.password;
  if (!password) return res.status(400).json({ error: 'Contrasena requerida' });
  try {
    if (!verifyPassword(password)) return res.status(401).json({ error: 'Contrasena incorrecta' });
  } catch(e) { return res.status(401).json({ error: 'Contrasena incorrecta' }); }
  const token = generateToken();
  sessions.set(token, { token: token, createdAt: Date.now() });
  res.setHeader('Set-Cookie', 'gl_session=' + token + '; Path=/; Max-Age=' + (SESSION_TTL_MS / 1000) + '; HttpOnly; SameSite=Strict');
  res.json({ token: token, expiresIn: SESSION_TTL_MS });
});

app.post('/api/logout', requireAuth, function(req, res) {
  sessions.delete(req.session.token);
  res.setHeader('Set-Cookie', 'gl_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict');
  res.json({ ok: true });
});

app.post('/api/check-device', function(req, res) {
  const code = (req.body.code || '').toUpperCase().trim();
  if (!code) return res.status(400).json({ error: 'Codigo requerido', exists: false });
  if (!devices.has(code)) return res.json({ exists: false, code: code });
  const d = devices.get(code);
  res.json({ exists: true, code: d.code, label: d.label, online: d.online, lastSeen: d.lastSeen });
});

app.post('/api/register-device', function(req, res) {
  const code     = req.body.code;
  const password = req.body.password;
  try {
    if (!password || !verifyPassword(password)) return res.status(401).json({ error: 'Contrasena incorrecta' });
  } catch(e) { return res.status(401).json({ error: 'Contrasena incorrecta' }); }
  if (code && devices.has(code)) {
    const d = devices.get(code);
    return res.json({ code: d.code, label: d.label, existing: true });
  }
  const newCode = code || generateDeviceCode();
  const label   = 'Telefono ' + (devices.size + 1);
  devices.set(newCode, {
    code: newCode, label: label, registeredAt: new Date(),
    ws: null, online: false, lastSeen: null,
    viewers: new Set(), phoneNumber: null,
    lastBattery: undefined, lastCharging: false
  });
  saveDevices();
  res.json({ code: newCode, label: label, existing: false });
});

app.get('/api/devices', requireAuth, function(req, res) {
  const list = [];
  devices.forEach(function(d) {
    list.push({ code: d.code, label: d.label, online: d.online, lastSeen: d.lastSeen,
                registeredAt: d.registeredAt, viewers: d.viewers.size, phoneNumber: d.phoneNumber });
  });
  res.json({ devices: list });
});

app.post('/api/command/:code', requireAuth, function(req, res) {
  const code   = req.params.code;
  const action = req.body.action;
  const params = req.body.params || {};
  const d = devices.get(code);
  if (!d) return res.status(404).json({ error: 'No encontrado' });
  if (!d.online || !d.ws) return res.status(503).json({ error: 'Desconectado' });
  d.ws.send(JSON.stringify({ type: 'command', action: action, params: params }));
  res.json({ ok: true });
});

// ─── HTTP + WS SERVER ─────────────────────────────────────────────────────────
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server: server });

wss.on('connection', function(ws, req) {
  const url      = new URL(req.url, 'http://localhost');
  const code     = url.searchParams.get('code');
  const role     = url.searchParams.get('role');
  const headerPw = req.headers['x-device-password'];
  const queryPw  = url.searchParams.get('password');
  const queryTk  = url.searchParams.get('token');

  let authenticated = false;
  if (headerPw || queryPw) {
    try { authenticated = verifyPassword(headerPw || queryPw); } catch(e) {}
  }
  if (!authenticated && queryTk) {
    const s = sessions.get(queryTk);
    authenticated = !!(s && Date.now() - s.createdAt < SESSION_TTL_MS);
  }

  if (!code || !role) { ws.close(1008, 'Parametros invalidos'); return; }
  if (!authenticated) { ws.close(1008, 'No autorizado');        return; }

  if (role === 'device') {
    if (!devices.has(code)) { ws.close(1008, 'Dispositivo no registrado'); return; }
    const d = devices.get(code);
    if (d.ws && d.ws.readyState === WebSocket.OPEN) {
      d.ws.close(1000, 'Nueva conexion entrante');
    }
    d.ws = ws; d.online = true; d.lastSeen = new Date();
    console.log('[device] ' + code + ' conectado, viewers=' + d.viewers.size);

    d.viewers.forEach(function(v) {
      if (v.readyState === WebSocket.OPEN) {
        v.send(JSON.stringify({ type: 'device_info', label: d.label, phone_number: d.phoneNumber || null }));
        if (d.lastBattery !== undefined) {
          v.send(JSON.stringify({ type: 'device_status', battery: d.lastBattery, charging: d.lastCharging || false }));
        }
      }
    });

    if (d.viewers.size > 0) {
      setTimeout(function() {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'command', action: 'camera_rear', params: {} }));
          console.log('[device] ' + code + ' — auto-restart camera (viewers activos)');
        }
      }, 1500);
    }

    ws.on('message', function(message, isBinary) {
      if (isBinary) {
        d.viewers.forEach(function(v) { if (v.readyState === WebSocket.OPEN) v.send(message, { binary: true }); });
        return;
      }
      try {
        const text = Buffer.isBuffer(message) ? message.toString() : message;
        const msg = JSON.parse(text);
        if (msg.type === 'device_info') {
          if (msg.label) d.label = msg.label;
          saveDevices();
          d.viewers.forEach(function(v) { if (v.readyState === WebSocket.OPEN) v.send(text); });
        } else if (msg.type === 'device_status') {
          if (msg.phone_number) { d.phoneNumber = msg.phone_number; saveDevices(); }
          if (msg.battery !== undefined) { d.lastBattery = msg.battery; d.lastCharging = msg.charging || false; }
          d.viewers.forEach(function(v) { if (v.readyState === WebSocket.OPEN) v.send(text); });
        } else if (msg.type === 'pong' || msg.type === 'audio_chunk') {
          d.viewers.forEach(function(v) { if (v.readyState === WebSocket.OPEN) v.send(text); });
        } else if (msg.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong' }));
        }
      } catch(e) {
        if (Buffer.isBuffer(message)) {
          d.viewers.forEach(function(v) { if (v.readyState === WebSocket.OPEN) v.send(message, { binary: true }); });
        }
      }
    });

    var devicePingInterval = setInterval(function() {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'ping' }));
      } else {
        clearInterval(devicePingInterval);
      }
    }, 30000);

    ws.on('close', function() {
      clearInterval(devicePingInterval);
      d.online = false; d.ws = null;
      console.log('[device] ' + code + ' desconectado');
      d.viewers.forEach(function(v) {
        if (v.readyState === WebSocket.OPEN) v.send(JSON.stringify({ type: 'device_offline' }));
      });
    });

  } else if (role === 'viewer') {
    if (!devices.has(code)) { ws.close(1008, 'Dispositivo no encontrado'); return; }
    const d = devices.get(code);
    d.viewers.add(ws);
    console.log('[viewer] conectado a ' + code);

    if (d.online) {
      ws.send(JSON.stringify({ type: 'device_info', label: d.label, phone_number: d.phoneNumber || null }));
      if (d.lastBattery !== undefined) {
        ws.send(JSON.stringify({ type: 'device_status', battery: d.lastBattery, charging: d.lastCharging || false }));
      }
      setTimeout(function() {
        if (d.ws && d.ws.readyState === WebSocket.OPEN) {
          d.ws.send(JSON.stringify({ type: 'command', action: 'camera_rear', params: {} }));
          console.log('[viewer] conectado — enviando camera_rear a ' + code);
        }
      }, 800);
    }

    var viewerHeartbeat = setInterval(function() {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'heartbeat' }));
      } else {
        clearInterval(viewerHeartbeat);
      }
    }, 15000);

    ws.on('message', function(message) {
      try {
        const msg = JSON.parse(message);
        if (msg.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong' }));
          return;
        }
        if (msg.type === 'command' && d.ws && d.ws.readyState === WebSocket.OPEN) {
          d.ws.send(message);
        }
      } catch(e) {}
    });

    ws.on('close', function() {
      clearInterval(viewerHeartbeat);
      d.viewers.delete(ws);
      console.log('[viewer] desconectado de ' + code);
    });
  }
});

server.listen(PORT, function() {
  console.log('GuardianLink escuchando en el puerto ' + PORT);
});
