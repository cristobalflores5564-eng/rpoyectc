# Remote Monitor — Android App

Aplicación profesional para convertir un dispositivo Android en un sistema de monitoreo remoto.

---

## Estructura del proyecto

```
RemoteMonitor/
├── app/
│   ├── src/main/
│   │   ├── java/com/remotemonitor/
│   │   │   ├── RemoteMonitorApp.kt          ← Application: canales de notificación, Timber
│   │   │   ├── data/
│   │   │   │   ├── model/
│   │   │   │   │   ├── ServerConfig.kt      ← Modelo de configuración del servidor
│   │   │   │   │   ├── ConnectionState.kt   ← Sealed class del estado de conexión
│   │   │   │   │   └── LogEvent.kt          ← Entidad Room para logs
│   │   │   │   ├── local/
│   │   │   │   │   ├── AppDatabase.kt       ← Base de datos Room (singleton)
│   │   │   │   │   └── LogEventDao.kt       ← DAO para operaciones de log
│   │   │   │   ├── preferences/
│   │   │   │   │   └── PreferencesManager.kt ← DataStore para configuración persistente
│   │   │   │   └── repository/
│   │   │   │       └── LogRepository.kt     ← Repositorio MVVM para logs
│   │   │   ├── network/
│   │   │   │   ├── WebSocketClient.kt       ← Cliente WebSocket con reconexión automática
│   │   │   │   └── AuthManager.kt           ← Autenticación JWT / Basic Auth
│   │   │   ├── service/
│   │   │   │   └── MonitoringService.kt     ← ForegroundService principal
│   │   │   ├── receiver/
│   │   │   │   ├── BootReceiver.kt          ← Inicio automático al arrancar
│   │   │   │   └── NetworkChangeReceiver.kt ← Detecta cambios de red
│   │   │   └── ui/
│   │   │       ├── main/
│   │   │       │   ├── MainActivity.kt      ← Activity única (Single Activity)
│   │   │       │   ├── MainViewModel.kt     ← ViewModel compartido
│   │   │       │   └── HomeFragment.kt      ← Pantalla principal
│   │   │       ├── logs/
│   │   │       │   ├── LogsFragment.kt      ← Lista de eventos
│   │   │       │   └── LogEventAdapter.kt   ← RecyclerView adapter
│   │   │       ├── permissions/
│   │   │       │   ├── PermissionsFragment.kt    ← Estado de permisos
│   │   │       │   ├── PermissionStatusAdapter.kt ← RecyclerView de permisos
│   │   │       │   └── PermissionManager.kt      ← Lógica de permisos centralizada
│   │   │       └── settings/
│   │   │           └── SettingsActivity.kt  ← Configuración del servidor y video
│   │   ├── AndroidManifest.xml              ← Permisos, components, declaraciones
│   │   └── res/
│   │       ├── layout/                      ← Layouts XML (Material Design 3)
│   │       ├── navigation/nav_graph.xml     ← Grafo de navegación
│   │       ├── menu/                        ← Menús de toolbar y bottom nav
│   │       ├── drawable/                    ← Iconos vectoriales
│   │       └── values/                      ← Strings, colores, temas
│   └── build.gradle                         ← Dependencias del módulo
└── build.gradle                             ← Configuración raíz del proyecto
```

---

## Cómo compilar en Android Studio (cuando tengas Debian 12)

### Requisitos
- Android Studio Hedgehog (2023.1.1) o superior
- JDK 17 (incluido con Android Studio)
- Android SDK API 34
- Gradle 8.2.x (descarga automática)

### Pasos

1. **Clonar / copiar el proyecto**
   ```bash
   # Copiar la carpeta RemoteMonitor/ al equipo con Debian 12
   ```

2. **Abrir en Android Studio**
   - File → Open → seleccionar la carpeta `RemoteMonitor/`
   - Esperar a que Gradle sincronice (puede tardar unos minutos la primera vez)

3. **Conectar el teléfono**
   - Habilitar Opciones de desarrollador → Depuración USB
   - Conectar por USB
   - Aceptar el aviso de depuración en el teléfono

4. **Compilar el APK de debug**
   ```bash
   # En la terminal de Android Studio o en Debian:
   cd RemoteMonitor
   ./gradlew assembleDebug
   # APK generado en: app/build/outputs/apk/debug/app-debug.apk
   ```

5. **Compilar el APK de release (firmado)**
   ```bash
   # Primero generar un keystore (solo una vez):
   keytool -genkey -v -keystore remotemonitor.jks -keyalg RSA -keysize 2048 -validity 10000 -alias remotemonitor

   # Luego en build.gradle agregar la configuración de firma y ejecutar:
   ./gradlew assembleRelease
   # APK en: app/build/outputs/apk/release/app-release.apk
   ```

6. **Instalar directamente en el teléfono conectado**
   ```bash
   ./gradlew installDebug
   ```

---

## Configurar el servidor

1. Abrir la app → icono de ajustes (⚙)
2. Ingresar la URL del servidor (ej: `https://tuservidor.com`)
3. Puerto (ej: `8443`)
4. Usuario/contraseña o token JWT
5. Guardar → volver al inicio → "Iniciar servicio"

### Protocolo WebSocket esperado por el servidor

El cliente se conecta a `wss://servidor:puerto/ws` con el header:
```
Authorization: Bearer <token>
```
o
```
Authorization: Basic <base64(usuario:contraseña)>
```

---

## Permisos solicitados en tiempo de ejecución

| Permiso | Por qué |
|---------|---------|
| CAMERA | Transmitir video al servidor |
| RECORD_AUDIO | Transmitir audio al servidor |
| POST_NOTIFICATIONS | Mostrar estado del servicio (Android 13+) |
| REQUEST_IGNORE_BATTERY_OPTIMIZATIONS | Funcionar continuamente en segundo plano (opcional, el usuario decide) |

---

## Decisiones técnicas

| Decisión | Razón |
|----------|-------|
| `LifecycleService` en lugar de `Service` | Permite coroutines y LiveData sin gestión manual del ciclo de vida |
| `DataStore` en lugar de `SharedPreferences` | Asíncrono, seguro con coroutines, no bloquea el hilo principal |
| `OkHttp WebSocket` | Más estable y maduro que librerías de terceros; soporte TLS nativo |
| `Room` para logs | Persistencia confiable; consultas reactivas con LiveData |
| Backoff exponencial | Evita saturar el servidor con reconexiones en ráfaga |
| `PARTIAL_WAKE_LOCK` | Mantiene CPU activa sin encender la pantalla (ahorro de batería) |
| Single Activity + Navigation Component | Patrón recomendado por Google; transiciones fluidas |
