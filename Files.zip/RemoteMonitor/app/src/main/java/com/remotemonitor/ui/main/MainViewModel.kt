package com.remotemonitor.ui.main

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.remotemonitor.data.local.AppDatabase
import com.remotemonitor.data.model.ConnectionState
import com.remotemonitor.data.model.LogEvent
import com.remotemonitor.data.model.ServerConfig
import com.remotemonitor.data.preferences.PreferencesManager
import com.remotemonitor.data.repository.LogRepository
import com.remotemonitor.network.DeviceRegistrationManager
import com.remotemonitor.service.MonitoringService
import com.remotemonitor.ui.permissions.PermissionManager
import com.remotemonitor.ui.permissions.PermissionStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * MainViewModel
 *
 * ViewModel de la pantalla principal. Es el intermediario entre la UI y los datos.
 *
 * Por qué AndroidViewModel en lugar de ViewModel:
 * - Necesitamos el contexto de aplicación para iniciar el servicio y leer preferencias
 * - AndroidViewModel recibe el Application (no Activity), por lo que no hay memory leak
 *
 * Responsabilidades:
 * - Exponer el estado de conexión (LiveData)
 * - Exponer la lista de logs (LiveData)
 * - Manejar las acciones del usuario (iniciar/detener servicio)
 * - Gestionar el estado de los permisos
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext: Context = application.applicationContext

    // ===================== DEPENDENCIAS =====================

    private val preferencesManager = PreferencesManager(appContext)
    private val db                 = AppDatabase.getInstance(appContext)
    val logRepository              = LogRepository(db.logEventDao())
    private val permissionManager  = PermissionManager(appContext)
    private val registrationManager = DeviceRegistrationManager(appContext)

    // ===================== CÓDIGO DE DISPOSITIVO =====================

    /** El código único del teléfono, generado al primer registro */
    val deviceCode: LiveData<String?> = registrationManager.deviceCodeFlow.asLiveData()

    // ===================== ESTADO DE SERVICIO =====================

    private val _serviceRunning = MutableLiveData<Boolean>(false)
    /** True si el MonitoringService está activo */
    val serviceRunning: LiveData<Boolean> = _serviceRunning

    private val _connectionState = MutableLiveData<ConnectionState>(ConnectionState.Disconnected)
    /** Estado actual de la conexión WebSocket */
    val connectionState: LiveData<ConnectionState> = _connectionState

    // ===================== CONFIGURACIÓN =====================

    /**
     * La configuración se expone como StateFlow convertido a LiveData.
     * Cuando el usuario cambia algo en ajustes, la UI se actualiza sola.
     */
    val serverConfig: LiveData<ServerConfig> = preferencesManager.serverConfigFlow
        .stateIn(
            scope         = viewModelScope,
            started       = SharingStarted.WhileSubscribed(5000),
            initialValue  = ServerConfig()
        )
        .asLiveData()

    // ===================== LOGS =====================

    /** LiveData de todos los eventos de log, observado por el Fragment de logs */
    val logEvents: LiveData<List<LogEvent>> = logRepository.allEvents

    // ===================== PERMISOS =====================

    private val _permissionStatus = MutableLiveData<List<PermissionStatus>>()
    val permissionStatus: LiveData<List<PermissionStatus>> = _permissionStatus

    private val _allPermissionsGranted = MutableLiveData<Boolean>(false)
    val allPermissionsGranted: LiveData<Boolean> = _allPermissionsGranted

    // ===================== MENSAJES DE EVENTO ÚNICO =====================
    // SingleLiveEvent evita que el evento se re-dispare al rotar la pantalla

    private val _snackbarMessage = MutableLiveData<String?>()
    val snackbarMessage: LiveData<String?> = _snackbarMessage

    // ===================== INICIALIZACIÓN =====================

    init {
        // Limpiar logs de más de 7 días al iniciar
        logRepository.purgeOldLogs(7)
        // Cargar estado de permisos
        refreshPermissionStatus()
        Timber.d("MainViewModel inicializado")
    }

    // ===================== ACCIONES DEL USUARIO =====================

    /**
     * Inicia el MonitoringService como ForegroundService.
     * Llamado cuando el usuario pulsa el botón "Iniciar".
     */
    fun startService() {
        if (_serviceRunning.value == true) {
            _snackbarMessage.value = "El servicio ya está en ejecución"
            return
        }

        Timber.i("Usuario solicitó iniciar el servicio")
        logRepository.logInfo("MainViewModel", "Usuario inició el servicio de monitoreo")

        val intent = MonitoringService.startIntent(appContext)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            appContext.startForegroundService(intent)
        } else {
            appContext.startService(intent)
        }

        _serviceRunning.value = true
        _connectionState.value = ConnectionState.Connecting
    }

    /**
     * Detiene el MonitoringService.
     * Llamado cuando el usuario pulsa el botón "Detener".
     */
    fun stopService() {
        if (_serviceRunning.value == false) {
            _snackbarMessage.value = "El servicio no está en ejecución"
            return
        }

        Timber.i("Usuario solicitó detener el servicio")
        logRepository.logInfo("MainViewModel", "Usuario detuvo el servicio de monitoreo")

        appContext.startService(MonitoringService.stopIntent(appContext))
        _serviceRunning.value = false
        _connectionState.value = ConnectionState.Disconnected
    }

    /**
     * Alterna entre iniciar y detener el servicio.
     */
    fun toggleService() {
        if (_serviceRunning.value == true) {
            stopService()
        } else {
            startService()
        }
    }

    // ===================== PERMISOS =====================

    /**
     * Actualiza la lista de estados de permisos.
     * Llamar después de que el usuario concede o deniega permisos.
     */
    fun refreshPermissionStatus() {
        val statuses = permissionManager.getPermissionStatus()
        _permissionStatus.value = statuses
        _allPermissionsGranted.value = permissionManager.allPermissionsGranted()
    }

    // ===================== LOGS =====================

    fun clearLogs() {
        viewModelScope.launch {
            logRepository.clearAll()
        }
    }

    // ===================== UTILIDADES =====================

    fun clearSnackbarMessage() {
        _snackbarMessage.value = null
    }

    /**
     * Actualiza el estado de conexión (llamado desde el servicio a través de un Intent
     * o desde un LocalBroadcastManager en implementaciones más avanzadas).
     */
    fun updateConnectionState(state: ConnectionState) {
        _connectionState.postValue(state)
    }

    fun updateServiceRunning(running: Boolean) {
        _serviceRunning.postValue(running)
    }
}
