package com.remotemonitor.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import timber.log.Timber

/**
 * NetworkChangeReceiver
 *
 * BroadcastReceiver que detecta cambios en la conectividad de red.
 * Cuando se recupera la conexión a internet, notifica al servicio
 * para que intente reconectar el WebSocket.
 *
 * Nota: En Android 7+, CONNECTIVITY_CHANGE solo se recibe cuando la app
 * está en primer plano. Para segundo plano, el WebSocketClient maneja
 * la reconexión con su propio mecanismo de backoff exponencial.
 *
 * Este receiver complementa ese mecanismo cuando la app está en primer plano.
 */
class NetworkChangeReceiver : BroadcastReceiver() {

    /** Callback que el servicio o ViewModel registra para recibir notificaciones */
    var onNetworkRestored: (() -> Unit)? = null
    var onNetworkLost: (() -> Unit)? = null

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.net.conn.CONNECTIVITY_CHANGE") return

        val isConnected = isNetworkAvailable(context)
        Timber.d("NetworkChangeReceiver: red ${if (isConnected) "disponible" else "no disponible"}")

        if (isConnected) {
            onNetworkRestored?.invoke()
        } else {
            onNetworkLost?.invoke()
        }
    }

    companion object {
        /**
         * Verifica si hay conectividad activa a internet.
         * Funciona correctamente en Android 10+ usando NetworkCapabilities.
         */
        fun isNetworkAvailable(context: Context): Boolean {
            val cm = context.getSystemService(ConnectivityManager::class.java)
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                   caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }
    }
}
