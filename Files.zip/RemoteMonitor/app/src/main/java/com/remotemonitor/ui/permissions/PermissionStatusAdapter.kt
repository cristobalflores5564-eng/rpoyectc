package com.remotemonitor.ui.permissions

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.remotemonitor.R
import com.remotemonitor.databinding.ItemPermissionStatusBinding

/**
 * PermissionStatusAdapter
 *
 * Adapter para la lista de permisos en PermissionsFragment.
 * Muestra cada permiso con su estado (concedido/denegado) y botón de acción.
 *
 * @param onRequestPermission  Callback para solicitar un permiso individual
 * @param onOpenSettings       Callback para abrir los ajustes del sistema
 */
class PermissionStatusAdapter(
    private val onRequestPermission: (PermissionInfo) -> Unit,
    private val onOpenSettings: () -> Unit
) : ListAdapter<PermissionStatus, PermissionStatusAdapter.PermissionViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PermissionViewHolder {
        val binding = ItemPermissionStatusBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return PermissionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PermissionViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class PermissionViewHolder(
        private val binding: ItemPermissionStatusBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(status: PermissionStatus) {
            binding.tvPermissionName.text      = status.info.title
            binding.tvPermissionRationale.text = status.info.rationale

            if (status.granted) {
                binding.ivPermissionStatus.setImageResource(R.drawable.ic_check_circle)
                binding.ivPermissionStatus.setColorFilter(
                    binding.root.context.getColor(R.color.status_ok)
                )
                binding.btnGrantPermission.visibility = android.view.View.GONE
            } else {
                binding.ivPermissionStatus.setImageResource(R.drawable.ic_error_circle)
                binding.ivPermissionStatus.setColorFilter(
                    binding.root.context.getColor(R.color.status_warning)
                )
                binding.btnGrantPermission.visibility = android.view.View.VISIBLE
                binding.btnGrantPermission.setOnClickListener {
                    onRequestPermission(status.info)
                }
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<PermissionStatus>() {
        override fun areItemsTheSame(old: PermissionStatus, new: PermissionStatus) =
            old.info.permission == new.info.permission
        override fun areContentsTheSame(old: PermissionStatus, new: PermissionStatus) =
            old == new
    }
}
