package com.remotemonitor.ui.logs

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.view.MenuProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.remotemonitor.R
import com.remotemonitor.databinding.FragmentLogsBinding
import com.remotemonitor.ui.main.MainViewModel

/**
 * LogsFragment
 *
 * Muestra la lista de eventos de log registrados por la aplicación.
 * Los logs se persisten en la base de datos Room y se actualizan en tiempo real
 * gracias al LiveData del DAO.
 *
 * RecyclerView con LinearLayoutManager inverso: los logs más nuevos aparecen arriba.
 */
class LogsFragment : Fragment() {

    private var _binding: FragmentLogsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: LogEventAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLogsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupObservers()
        setupMenu()
    }

    private fun setupRecyclerView() {
        adapter = LogEventAdapter()

        binding.recyclerViewLogs.apply {
            this.adapter = this@LogsFragment.adapter
            layoutManager = LinearLayoutManager(requireContext()).apply {
                // Los logs nuevos se insertan al inicio de la lista (reversed)
                reverseLayout = true
                stackFromEnd  = false
            }
            // Mejor rendimiento: el tamaño del RecyclerView no cambia al actualizar items
            setHasFixedSize(false)
        }
    }

    private fun setupObservers() {
        viewModel.logEvents.observe(viewLifecycleOwner) { events ->
            adapter.submitList(events)

            // Mostrar estado vacío si no hay logs
            if (events.isNullOrEmpty()) {
                binding.recyclerViewLogs.visibility = View.GONE
                binding.layoutEmptyLogs.visibility  = View.VISIBLE
            } else {
                binding.recyclerViewLogs.visibility = View.VISIBLE
                binding.layoutEmptyLogs.visibility  = View.GONE
                binding.tvLogCount.text             = "${events.size} eventos"
            }
        }
    }

    /**
     * Agrega un menú contextual al Fragment usando la API moderna MenuProvider.
     * Esto es más limpio que sobreescribir onCreateOptionsMenu en el Fragment.
     */
    private fun setupMenu() {
        requireActivity().addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                menuInflater.inflate(R.menu.logs_menu, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                return when (menuItem.itemId) {
                    R.id.action_clear_logs -> {
                        showClearLogsDialog()
                        true
                    }
                    else -> false
                }
            }
        }, viewLifecycleOwner, Lifecycle.State.RESUMED)
    }

    private fun showClearLogsDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Limpiar logs")
            .setMessage("¿Eliminar todos los eventos del registro? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ -> viewModel.clearLogs() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
