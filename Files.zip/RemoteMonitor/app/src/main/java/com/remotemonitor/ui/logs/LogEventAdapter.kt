package com.remotemonitor.ui.logs

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.remotemonitor.R
import com.remotemonitor.data.model.LogEvent
import com.remotemonitor.data.model.LogLevel
import com.remotemonitor.databinding.ItemLogEventBinding

/**
 * LogEventAdapter
 *
 * Adapter del RecyclerView para mostrar la lista de LogEvents.
 *
 * Usa ListAdapter con DiffUtil para actualizaciones eficientes:
 * - Solo anima los items que realmente cambiaron
 * - Evita repintar toda la lista en cada update
 * - DiffUtil calcula las diferencias en un hilo secundario
 *
 * ViewBinding: acceso seguro a las vistas del item sin findViewById.
 */
class LogEventAdapter : ListAdapter<LogEvent, LogEventAdapter.LogViewHolder>(LogDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LogViewHolder {
        val binding = ItemLogEventBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return LogViewHolder(binding)
    }

    override fun onBindViewHolder(holder: LogViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    // ===================== VIEW HOLDER =====================

    class LogViewHolder(
        private val binding: ItemLogEventBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(event: LogEvent) {
            binding.tvLogTime.text    = event.formattedTime()
            binding.tvLogTag.text     = event.tag
            binding.tvLogMessage.text = event.message
            binding.tvLogLevel.text   = "${event.level.emoji} ${event.level.name}"

            // Color de fondo del badge de nivel según severidad
            val levelColor = when (event.level) {
                LogLevel.DEBUG   -> R.color.log_debug
                LogLevel.INFO    -> R.color.log_info
                LogLevel.WARNING -> R.color.log_warning
                LogLevel.ERROR   -> R.color.log_error
            }
            binding.tvLogLevel.setTextColor(
                ContextCompat.getColor(binding.root.context, levelColor)
            )
        }
    }

    // ===================== DIFF CALLBACK =====================

    /**
     * DiffUtil.ItemCallback compara items para detectar cambios sin redibujar toda la lista.
     * areItemsTheSame: compara IDs (¿es el mismo item?)
     * areContentsTheSame: compara contenido (¿cambió el item?)
     */
    class LogDiffCallback : DiffUtil.ItemCallback<LogEvent>() {
        override fun areItemsTheSame(old: LogEvent, new: LogEvent) = old.id == new.id
        override fun areContentsTheSame(old: LogEvent, new: LogEvent) = old == new
    }
}
