package com.remotemonitor.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.remotemonitor.data.model.ServerConfig
import com.remotemonitor.data.model.VideoQuality
import com.remotemonitor.data.model.VideoResolution
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Extensión del Context para crear/acceder al DataStore.
// Esto garantiza que solo existe una instancia del DataStore por nombre.
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(
    name = "remote_monitor_preferences"
)

/**
 * PreferencesManager
 *
 * Maneja la persistencia de la configuración del usuario usando Jetpack DataStore.
 * DataStore es la alternativa moderna a SharedPreferences: es asíncrono, seguro
 * con coroutines y evita bloqueos en el hilo principal.
 *
 * Patrón Repository: la UI nunca accede directamente al DataStore,
 * siempre a través de esta clase.
 */
class PreferencesManager(private val context: Context) {

    // ===================== CLAVES DE PREFERENCIAS =====================
    // Cada clave tiene un tipo fuerte (String, Int, Boolean)
    private object Keys {
        val SERVER_URL     = stringPreferencesKey("server_url")
        val PORT           = intPreferencesKey("port")
        val USERNAME       = stringPreferencesKey("username")
        val PASSWORD       = stringPreferencesKey("password")
        val TOKEN          = stringPreferencesKey("token")
        val USE_TLS        = booleanPreferencesKey("use_tls")
        val VIDEO_QUALITY  = stringPreferencesKey("video_quality")
        val RESOLUTION     = stringPreferencesKey("resolution")
        val FPS            = intPreferencesKey("fps")
        val AUTO_CONNECT   = booleanPreferencesKey("auto_connect")
        val AUTO_START     = booleanPreferencesKey("auto_start_on_boot")
    }

    // ===================== LECTURA (Flow reactivo) =====================

    /**
     * Flow que emite la configuración actual.
     * Se actualiza automáticamente cuando cambia cualquier valor.
     * La UI puede observarlo con collectAsState() o lifecycleScope.
     */
    val serverConfigFlow: Flow<ServerConfig> = context.dataStore.data.map { prefs ->
        ServerConfig(
            serverUrl    = prefs[Keys.SERVER_URL]?.takeIf { it.isNotBlank() && it != "https://" && it != "http://" }
                           ?: ServerConfig().serverUrl,
            port         = prefs[Keys.PORT] ?: 443,
            username     = prefs[Keys.USERNAME] ?: "",
            password     = prefs[Keys.PASSWORD] ?: "",
            token        = prefs[Keys.TOKEN] ?: "",
            useTls       = prefs[Keys.USE_TLS] ?: true,
            videoQuality = VideoQuality.valueOf(prefs[Keys.VIDEO_QUALITY] ?: VideoQuality.MEDIUM.name),
            resolution   = VideoResolution.valueOf(prefs[Keys.RESOLUTION] ?: VideoResolution.HD_720P.name),
            fps          = prefs[Keys.FPS] ?: 15,
            autoConnect  = prefs[Keys.AUTO_CONNECT] ?: true
        )
    }

    /** Si el servicio debe iniciarse automáticamente al arrancar el teléfono */
    val autoStartOnBoot: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.AUTO_START] ?: false
    }

    // ===================== ESCRITURA (suspend functions) =====================

    /**
     * Guarda la configuración completa del servidor.
     * DataStore garantiza operaciones atómicas: se guarda todo o nada.
     */
    suspend fun saveServerConfig(config: ServerConfig) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SERVER_URL]    = config.serverUrl
            prefs[Keys.PORT]          = config.port
            prefs[Keys.USERNAME]      = config.username
            prefs[Keys.PASSWORD]      = config.password
            prefs[Keys.TOKEN]         = config.token
            prefs[Keys.USE_TLS]       = config.useTls
            prefs[Keys.VIDEO_QUALITY] = config.videoQuality.name
            prefs[Keys.RESOLUTION]    = config.resolution.name
            prefs[Keys.FPS]           = config.fps
            prefs[Keys.AUTO_CONNECT]  = config.autoConnect
        }
    }

    /** Guarda solo la preferencia de inicio automático al arrancar */
    suspend fun setAutoStartOnBoot(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AUTO_START] = enabled
        }
    }

    /**
     * Limpia todas las preferencias (útil para "Restablecer configuración").
     */
    suspend fun clearAll() {
        context.dataStore.edit { it.clear() }
    }
}
