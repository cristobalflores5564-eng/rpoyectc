package com.remotemonitor.data.model

/**
 * ServerConfig
 *
 * Modelo de datos que representa la configuración de conexión al servidor remoto.
 * Esta clase es un simple data class de Kotlin: inmutable, con equals/hashCode/copy
 * generados automáticamente.
 *
 * @param serverUrl     URL base del servidor (ej: "https://miservidor.com")
 * @param port          Puerto de conexión (ej: 8443)
 * @param username      Usuario para autenticación
 * @param password      Contraseña (nunca se loguea ni se imprime)
 * @param token         Token JWT alternativo a usuario/contraseña
 * @param useTls        Si la conexión debe usar TLS (siempre true en producción)
 * @param videoQuality  Calidad del video: LOW, MEDIUM, HIGH
 * @param resolution    Resolución de video: "640x480", "1280x720", etc.
 * @param fps           Frames por segundo objetivo
 * @param autoConnect   Reconectar automáticamente al iniciar el servicio
 */
data class ServerConfig(
    val serverUrl: String = "http://novaforge.chickenkiller.com",
    val port: Int = 80,
    val username: String = "",
    val password: String = "",
    val token: String = "",
    val useTls: Boolean = false,
    val videoQuality: VideoQuality = VideoQuality.MEDIUM,
    val resolution: VideoResolution = VideoResolution.HD_720P,
    val fps: Int = 15,
    val autoConnect: Boolean = true
) {
    /**
     * Construye la URL base HTTP/HTTPS limpia.
     * Usa serverUrl directamente — ya contiene host y puerto.
     */
    fun buildHttpsUrl(): String = serverUrl.trimEnd('/')

    /**
     * Construye la URL del WebSocket a partir de serverUrl.
     * Reemplaza http→ws y https→wss automáticamente.
     */
    fun buildWebSocketUrl(): String {
        val base = serverUrl.trimEnd('/')
        return when {
            base.startsWith("https://") -> base.replace("https://", "wss://") + "/ws"
            base.startsWith("http://")  -> base.replace("http://",  "ws://")  + "/ws"
            else                        -> "ws://$base/ws"
        }
    }
}

/**
 * Niveles de calidad de video disponibles.
 * Afectan directamente al bitrate y consumo de batería/datos.
 */
enum class VideoQuality(val bitrate: Int, val displayName: String) {
    LOW(500_000, "Baja (500 kbps)"),
    MEDIUM(1_500_000, "Media (1.5 Mbps)"),
    HIGH(4_000_000, "Alta (4 Mbps)")
}

/**
 * Resoluciones de video soportadas.
 * Se mapean a los tamaños que Camera2 API puede entregar.
 */
enum class VideoResolution(val width: Int, val height: Int, val displayName: String) {
    SD_480P(640, 480, "480p (640×480)"),
    HD_720P(1280, 720, "720p (1280×720)"),
    FHD_1080P(1920, 1080, "1080p (1920×1080)")
}
