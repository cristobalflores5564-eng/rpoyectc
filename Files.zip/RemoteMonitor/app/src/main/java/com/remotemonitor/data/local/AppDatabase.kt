package com.remotemonitor.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.remotemonitor.data.model.LogEvent

/**
 * AppDatabase
 *
 * Base de datos local usando Room (capa de abstracción sobre SQLite).
 * Room genera automáticamente el código SQL necesario a partir de las anotaciones.
 *
 * Patrón Singleton: solo existe una instancia en toda la app para evitar
 * condiciones de carrera y desperdicio de recursos.
 *
 * @Database: declara las entidades (tablas) y la versión del esquema.
 */
@Database(
    entities = [LogEvent::class],
    version = 1,
    exportSchema = false  // En producción se recomienda true y migración controlada
)
abstract class AppDatabase : RoomDatabase() {

    /**
     * Room genera la implementación de este DAO automáticamente en tiempo de compilación.
     */
    abstract fun logEventDao(): LogEventDao

    companion object {
        // @Volatile garantiza que los cambios a INSTANCE sean visibles a todos los hilos
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * Obtiene la instancia única de la base de datos.
         * Si no existe, la crea de forma thread-safe con synchronized.
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "remote_monitor.db"
                )
                    .fallbackToDestructiveMigration()  // Solo en dev; en prod usar Migration
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
