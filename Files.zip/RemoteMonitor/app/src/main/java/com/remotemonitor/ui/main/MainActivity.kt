package com.remotemonitor.ui.main

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.remotemonitor.R
import com.remotemonitor.network.DeviceRegistrationManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * MainActivity
 *
 * Solo se abre desde la notificación persistente.
 * Muestra el código del dispositivo en pantalla durante 10 segundos y se cierra.
 * No tiene icono en el launcher — no es una app normal.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_code_display)

        val tvCode  = findViewById<TextView>(R.id.tvDeviceCode)
        val tvLabel = findViewById<TextView>(R.id.tvDeviceLabel)

        val registrationManager = DeviceRegistrationManager(this)

        lifecycleScope.launch {
            val code  = registrationManager.getDeviceCode()  ?: "Sin código"
            val label = registrationManager.getDeviceLabel() ?: ""

            tvCode.text  = code
            tvLabel.text = label

            Timber.i("Código mostrado: $code")

            // Cerrar automáticamente después de 15 segundos
            delay(15_000)
            finishAndRemoveTask()
        }
    }

    override fun onPause() {
        super.onPause()
        // Cerrar cuando el usuario salga de la pantalla
        finishAndRemoveTask()
    }
}
