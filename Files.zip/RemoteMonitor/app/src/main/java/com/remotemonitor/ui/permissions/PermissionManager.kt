package com.remotemonitor.ui.permissions

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.core.content.ContextCompat
import timber.log.Timber

/**
 * PermissionManager
 *
 * Centraliza toda la lógica de permisos en tiempo de ejecución.
 *
 * Por qué una clase separada:
 * - Las Activities no deben tener lógica de negocio compleja
 * - Los permisos son una responsabilidad ortogonal a la UI
 * - Facilita el testing y la reutilización
 *
 * Permisos gestionados:
 * - CAMERA: captura de video
 * - RECORD_AUDIO: captura de audio
 * - POST_NOTIFICATIONS: mostrar notificaciones (Android 13+)
 */
class PermissionManager(private val context: Context) {

    /**
     * Lista de todos los permisos peligrosos que necesita la app.
     * Se solicitan en tiempo de ejecución (no basta con declararlos en el Manifest).
     */
    val requiredPermissions: List<PermissionInfo> = buildList {
        add(PermissionInfo(
            permission    = Manifest.permission.CAMERA,
            title         = "Cámara",
            rationale     = "La aplicación necesita acceso a la cámara para transmitir video al servidor de monitoreo.",
            isRequired    = false  // La app funciona sin cámara pero con funcionalidad reducida
        ))
        add(PermissionInfo(
            permission    = Manifest.permission.RECORD_AUDIO,
            title         = "Micrófono",
            rationale     = "La aplicación necesita el micrófono para transmitir audio al servidor de monitoreo.",
            isRequired    = false
        ))
        // POST_NOTIFICATIONS solo es necesario en Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(PermissionInfo(
                permission = Manifest.permission.POST_NOTIFICATIONS,
                title      = "Notificaciones",
                rationale  = "Las notificaciones son necesarias para mostrar el estado del servicio cuando la app está en segundo plano.",
                isRequired = true
            ))
        }
    }

    /**
     * Retorna true si todos los permisos requeridos están concedidos.
     */
    fun allPermissionsGranted(): Boolean {
        return requiredPermissions.all { isGranted(it.permission) }
    }

    /**
     * Retorna la lista de permisos que aún no han sido concedidos.
     */
    fun getMissingPermissions(): List<PermissionInfo> {
        return requiredPermissions.filter { !isGranted(it.permission) }
    }

    /**
     * Verifica si un permiso específico está concedido.
     */
    fun isGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) ==
               PackageManager.PERMISSION_GRANTED
    }

    /**
     * Retorna true si el usuario ha marcado "No volver a preguntar" para un permiso.
     * En ese caso, debemos redirigir al usuario a los ajustes del sistema.
     */
    fun isPermanentlyDenied(activity: Activity, permission: String): Boolean {
        return !isGranted(permission) &&
               !activity.shouldShowRequestPermissionRationale(permission)
    }

    /**
     * Construye el array de strings de permisos para pasarlo al launcher.
     */
    fun buildPermissionArray(): Array<String> {
        return getMissingPermissions().map { it.permission }.toTypedArray()
    }

    // ===================== OPTIMIZACIÓN DE BATERÍA =====================

    /**
     * Verifica si la app está excluida de la optimización de batería.
     * Cuando está excluida, Android no restringe su actividad en segundo plano.
     */
    fun isBatteryOptimizationIgnored(): Boolean {
        val pm = context.getSystemService(PowerManager::class.java)
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    /**
     * Abre la pantalla del sistema para solicitar la exclusión de la optimización de batería.
     * Android requiere que el usuario tome esta decisión manualmente.
     *
     * IMPORTANTE: No se puede solicitar este permiso directamente desde código
     * sin que el usuario lo apruebe explícitamente en la pantalla del sistema.
     */
    fun requestIgnoreBatteryOptimization(activity: Activity) {
        if (!isBatteryOptimizationIgnored()) {
            Timber.i("Solicitando exclusión de optimización de batería")
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            activity.startActivity(intent)
        }
    }

    /**
     * Abre los ajustes de la app en el sistema para que el usuario
     * conceda permisos que fueron denegados permanentemente.
     */
    fun openAppSettings(activity: Activity) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
        }
        activity.startActivity(intent)
    }

    /**
     * Retorna un resumen del estado de todos los permisos para mostrar en la UI.
     */
    fun getPermissionStatus(): List<PermissionStatus> {
        return requiredPermissions.map { info ->
            PermissionStatus(
                info    = info,
                granted = isGranted(info.permission)
            )
        }
    }
}

/**
 * Información descriptiva sobre un permiso.
 * Usada para mostrar explicaciones claras al usuario antes de solicitarlo.
 */
data class PermissionInfo(
    val permission : String,
    val title      : String,
    val rationale  : String,
    val isRequired : Boolean
)

/**
 * Estado actual de un permiso (información + si está concedido).
 */
data class PermissionStatus(
    val info    : PermissionInfo,
    val granted : Boolean
)
