package com.remotemonitor.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * LogEvent
 *
 * Entidad de Room (base de datos local SQLite) que representa un evento registrado.
 * Cada fila en la tabla "log_events" es un LogEvent.
 *
 * Usamos Room para persistir los logs aunque la app se reinicie.
 * Esto permite diagnóstico remoto y revisión de historial.
 *
 * @param id        Clave primaria autoincremental
 * @param timestamp Momento en que ocurrió el evento (milisegundos epoch)
 * @param level     Nivel: DEBUG, INFO, WARNING, ERROR
 * @param tag       Origen del log (nombre de la clase/componente)
 * @param message   Descripción del evento
 */
@Entity(tableName = "log_events")
data class LogEvent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel = LogLevel.INFO,
    val tag: String = "",
    val message: String = ""
) {
    /**
     * Formatea el timestamp a una cadena legible para la UI.
     */
    fun formattedTime(): String {
        val sdf = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    /**
     * Representación completa para mostrar en la lista de logs.
     */
    fun toDisplayString(): String = "[${formattedTime()}] [${level.name}] $tag: $message"
}

/**
 * Niveles de severidad del log, de menor a mayor.
 */
enum class LogLevel(val emoji: String) {
    DEBUG("🔍"),
    INFO("ℹ️"),
    WARNING("⚠️"),
    ERROR("❌")
}
