package com.remotemonitor.data.repository

import androidx.lifecycle.LiveData
import com.remotemonitor.data.local.LogEventDao
import com.remotemonitor.data.model.LogEvent
import com.remotemonitor.data.model.LogLevel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * LogRepository
 *
 * Repositorio que actúa como única fuente de verdad para los eventos de log.
 * En arquitectura MVVM, el repositorio abstrae el origen de los datos
 * (base de datos local, API remota, etc.) del ViewModel.
 *
 * La UI nunca debe acceder directamente al DAO.
 */
class LogRepository(private val dao: LogEventDao) {

    // Scope para operaciones en segundo plano (IO = optimizado para disco/red)
    private val scope = CoroutineScope(Dispatchers.IO)

    // ===================== LECTURA =====================

    /** LiveData que la UI observa para actualizarse automáticamente */
    val allEvents: LiveData<List<LogEvent>> = dao.getAllEventsLiveData()

    // ===================== ESCRITURA =====================

    /** Registra un evento INFO */
    fun logInfo(tag: String, message: String) {
        log(LogLevel.INFO, tag, message)
        Timber.tag(tag).i(message)
    }

    /** Registra un evento DEBUG */
    fun logDebug(tag: String, message: String) {
        log(LogLevel.DEBUG, tag, message)
        Timber.tag(tag).d(message)
    }

    /** Registra un evento de ADVERTENCIA */
    fun logWarning(tag: String, message: String) {
        log(LogLevel.WARNING, tag, message)
        Timber.tag(tag).w(message)
    }

    /** Registra un evento de ERROR */
    fun logError(tag: String, message: String, throwable: Throwable? = null) {
        log(LogLevel.ERROR, tag, message)
        if (throwable != null) {
            Timber.tag(tag).e(throwable, message)
        } else {
            Timber.tag(tag).e(message)
        }
    }

    /**
     * Inserta el evento en la base de datos en un hilo secundario.
     * Usamos fire-and-forget porque el log nunca debe bloquear el flujo principal.
     */
    private fun log(level: LogLevel, tag: String, message: String) {
        scope.launch {
            dao.insert(
                LogEvent(
                    level   = level,
                    tag     = tag,
                    message = message
                )
            )
        }
    }

    // ===================== MANTENIMIENTO =====================

    /** Elimina todos los logs */
    fun clearAll() {
        scope.launch { dao.deleteAll() }
    }

    /**
     * Elimina logs más viejos que N días para no acumular demasiado.
     * Se recomienda llamarlo al iniciar la app.
     */
    fun purgeOldLogs(olderThanDays: Int = 7) {
        scope.launch {
            val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(olderThanDays.toLong())
            dao.deleteOldEvents(cutoff)
            Timber.d("Logs anteriores a $olderThanDays días eliminados")
        }
    }
}
