package com.remotemonitor.network

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.remotemonitor.data.model.DeviceRegistration
import com.remotemonitor.data.model.ServerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.util.concurrent.TimeUnit

private val Context.deviceStore by preferencesDataStore(name = "device_identity")

/**
 * DeviceRegistrationManager
 *
 * Gestiona el código único de este teléfono.
 *
 * El flujo es:
 * 1. Primer arranque: no hay código → llamar registerDevice() → servidor devuelve código
 * 2. Guardar código en DataStore (sobrevive desinstalación con backup, o se regenera)
 * 3. Arranques siguientes: leer código guardado → usarlo directamente
 * 4. El código se usa como identificador en la conexión WebSocket
 *
 * La contraseña global MeCa12345@123 se usa para autenticar el registro
 * y también para la conexión WebSocket.
 */
class DeviceRegistrationManager(private val context: Context) {

    private val gson = Gson()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    companion object {
        private val KEY_DEVICE_CODE  = stringPreferencesKey("device_code")
        private val KEY_DEVICE_LABEL = stringPreferencesKey("device_label")

        // Contraseña global hardcoded en la app
        // En producción se puede obfuscar con Android Keystore
        const val DEVICE_PASSWORD = "MeCa12345@123"
    }

    // ─── LECTURA ─────────────────────────────────────────────────────────────

    /** Flow del código actual del dispositivo (null si no está registrado) */
    val deviceCodeFlow: Flow<String?> = context.deviceStore.data.map { prefs ->
        prefs[KEY_DEVICE_CODE]
    }

    /** Obtiene el código actual de forma síncrona (para uso en coroutines) */
    suspend fun getDeviceCode(): String? = deviceCodeFlow.first()

    /** Obtiene el label/nombre del dispositivo */
    suspend fun getDeviceLabel(): String? = context.deviceStore.data
        .map { it[KEY_DEVICE_LABEL] }.first()

    // ─── REGISTRO ────────────────────────────────────────────────────────────

    /**
     * Resultado del proceso de registro.
     */
    sealed class RegistrationResult {
        data class Success(val registration: DeviceRegistration) : RegistrationResult()
        data class AlreadyRegistered(val code: String, val label: String) : RegistrationResult()
        data class Failure(val error: String) : RegistrationResult()
    }

    /**
     * Registra este teléfono en el servidor y guarda el código.
     *
     * Si ya tiene código guardado, hace un re-registro (el servidor confirma
     * que el código sigue siendo válido).
     *
     * @param config Configuración del servidor con la URL base
     */
    suspend fun registerDevice(config: ServerConfig): RegistrationResult =
        withContext(Dispatchers.IO) {
            try {
                // Verificar si ya tenemos código guardado
                val existingCode = getDeviceCode()
                Timber.d("Código existente: ${existingCode ?: "ninguno"}")

                val body = buildMap<String, String> {
                    put("password", DEVICE_PASSWORD)
                    if (existingCode != null) put("code", existingCode)
                }.let { gson.toJson(it) }

                val registerUrl = "${config.buildHttpsUrl()}/api/register-device"
                Timber.i("URL de registro: $registerUrl")
                Timber.i("serverUrl raw: ${config.serverUrl}")
                Timber.i("buildHttpsUrl: ${config.buildHttpsUrl()}")

                val request = Request.Builder()
                    .url(registerUrl)
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()

                val response = httpClient.newCall(request).execute()
                val responseBody = response.body?.string() ?: ""

                if (!response.isSuccessful) {
                    val err = "Registro fallido: HTTP ${response.code}"
                    Timber.e(err)
                    return@withContext RegistrationResult.Failure(err)
                }

                val reg = gson.fromJson(responseBody, RegistrationResponse::class.java)

                // Guardar código y label en el dispositivo
                saveDeviceIdentity(reg.code, reg.label)

                Timber.i("Dispositivo registrado: ${reg.code} (${reg.label})")

                val result = DeviceRegistration(
                    code     = reg.code,
                    label    = reg.label,
                    existing = reg.existing
                )

                if (reg.existing) {
                    RegistrationResult.AlreadyRegistered(reg.code, reg.label)
                } else {
                    RegistrationResult.Success(result)
                }

            } catch (e: Exception) {
                Timber.e(e, "Error durante registro del dispositivo")
                RegistrationResult.Failure("Error de red: ${e.message}")
            }
        }

    /**
     * Guarda el código e identificador del dispositivo de forma permanente.
     */
    private suspend fun saveDeviceIdentity(code: String, label: String) {
        context.deviceStore.edit { prefs ->
            prefs[KEY_DEVICE_CODE]  = code
            prefs[KEY_DEVICE_LABEL] = label
        }
    }

    /**
     * Construye la URL del WebSocket para este dispositivo.
     * Formato: wss://servidor/ws?code=XXX&role=device
     * La contraseña va en el header X-Device-Password (no en la URL).
     */
    suspend fun buildDeviceWebSocketUrl(config: ServerConfig): String? {
        val code = getDeviceCode() ?: return null
        val wsBase = config.buildWebSocketUrl()
        // Contraseña en query param — más compatible con todos los proxies y servidores
        return "$wsBase?code=${encode(code)}&password=${encode(DEVICE_PASSWORD)}&role=device"
    }

    private fun encode(s: String) = java.net.URLEncoder.encode(s, "UTF-8")

    /** Modelo para parsear la respuesta JSON del endpoint /api/register-device */
    private data class RegistrationResponse(
        val code: String = "",
        val label: String = "",
        val existing: Boolean = false
    )
}
