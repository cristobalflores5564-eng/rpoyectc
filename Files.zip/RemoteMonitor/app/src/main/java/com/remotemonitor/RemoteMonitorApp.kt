package com.remotemonitor

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import timber.log.Timber

/**
 * RemoteMonitorApp
 *
 * Clase Application personalizada. Es el punto de entrada global de la app.
 * Se inicializa antes que cualquier Activity o Service.
 *
 * Responsabilidades:
 * - Inicializar Timber para logging profesional
 * - Crear canales de notificación (obligatorio en Android 8+)
 * - Proveer el contexto de aplicación a toda la app
 */
class RemoteMonitorApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Inicializar Timber solo en debug para no exponer logs en producción
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        // Crear canales de notificación
        createNotificationChannels()

        Timber.i("RemoteMonitorApp iniciada correctamente")
    }

    /**
     * Crea los canales de notificación necesarios.
     * En Android 8.0 (API 26) o superior, los canales son obligatorios
     * para mostrar notificaciones.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // Canal para el servicio de monitoreo en primer plano
            val serviceChannel = NotificationChannel(
                CHANNEL_ID_SERVICE,
                getString(R.string.notification_channel_service_name),
                NotificationManager.IMPORTANCE_LOW  // LOW = sin sonido, discreta
            ).apply {
                description = getString(R.string.notification_channel_service_desc)
                setShowBadge(false)  // No mostrar badge en el icono de la app
            }

            // Canal para alertas importantes
            val alertChannel = NotificationChannel(
                CHANNEL_ID_ALERTS,
                getString(R.string.notification_channel_alerts_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notification_channel_alerts_desc)
            }

            notificationManager.createNotificationChannels(
                listOf(serviceChannel, alertChannel)
            )

            Timber.d("Canales de notificación creados")
        }
    }

    companion object {
        // IDs de los canales de notificación (deben ser únicos en la app)
        const val CHANNEL_ID_SERVICE = "remote_monitor_service"
        const val CHANNEL_ID_ALERTS  = "remote_monitor_alerts"

        // ID de la notificación del servicio en primer plano
        const val NOTIFICATION_ID_SERVICE = 1001
    }
}
