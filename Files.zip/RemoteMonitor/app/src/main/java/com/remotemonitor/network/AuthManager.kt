package com.remotemonitor.network

import com.google.gson.Gson
import com.remotemonitor.data.model.ServerConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * AuthManager
 *
 * Gestiona la autenticación contra el servidor remoto.
 *
 * Soporta dos métodos:
 * 1. Token estático: se envía en el header "Authorization: Bearer <token>"
 * 2. Login REST: POST /auth/login con usuario/contraseña, recibe JWT
 *
 * Decisión técnica: separar la autenticación del WebSocket permite
 * reutilizar el token en múltiples conexiones y renovarlo sin desconectar.
 */
class AuthManager {

    private val gson = Gson()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    /**
     * Resultado de una operación de autenticación.
     */
    sealed class AuthResult {
        data class Success(val token: String) : AuthResult()
        data class Failure(val error: String) : AuthResult()
    }

    /**
     * Realiza el login REST para obtener un token JWT.
     *
     * Este método se debe llamar antes de conectar el WebSocket
     * si no se tiene un token estático configurado.
     *
     * @param config Configuración del servidor con usuario y contraseña
     * @return AuthResult.Success con el token, o AuthResult.Failure con el error
     */
    suspend fun login(config: ServerConfig): AuthResult = withContext(Dispatchers.IO) {
        if (config.token.isNotBlank()) {
            // Si ya tiene token, no necesitamos hacer login
            return@withContext AuthResult.Success(config.token)
        }

        if (config.username.isBlank()) {
            return@withContext AuthResult.Failure("No hay credenciales configuradas")
        }

        try {
            val loginUrl = "${config.buildHttpsUrl()}/auth/login"
            Timber.d("Intentando login en: $loginUrl")

            // Construir el cuerpo JSON de la petición
            val body = mapOf(
                "username" to config.username,
                "password" to config.password
            )
            val jsonBody = gson.toJson(body)
            val requestBody = jsonBody.toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(loginUrl)
                .post(requestBody)
                .addHeader("Accept", "application/json")
                .build()

            val response = httpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                val errorMsg = "Login fallido: HTTP ${response.code}"
                Timber.w(errorMsg)
                return@withContext AuthResult.Failure(errorMsg)
            }

            // Parsear la respuesta JSON para extraer el token
            val responseBody = response.body?.string() ?: ""
            val tokenResponse = gson.fromJson(responseBody, TokenResponse::class.java)

            if (tokenResponse.token.isBlank()) {
                return@withContext AuthResult.Failure("Respuesta del servidor no contiene token")
            }

            Timber.i("Login exitoso, token obtenido")
            AuthResult.Success(tokenResponse.token)

        } catch (e: Exception) {
            val msg = "Error de red durante login: ${e.message}"
            Timber.e(e, msg)
            AuthResult.Failure(msg)
        }
    }

    /**
     * Verifica si un token es válido haciendo una petición al endpoint de verificación.
     * Útil para validar tokens guardados antes de intentar conectar.
     */
    suspend fun verifyToken(config: ServerConfig, token: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val verifyUrl = "${config.buildHttpsUrl()}/auth/verify"
                val request = Request.Builder()
                    .url(verifyUrl)
                    .get()
                    .addHeader("Authorization", "Bearer $token")
                    .build()

                val response = httpClient.newCall(request).execute()
                val isValid = response.isSuccessful
                Timber.d("Verificación de token: ${if (isValid) "válido" else "inválido"}")
                isValid
            } catch (e: Exception) {
                Timber.w(e, "No se pudo verificar el token")
                false
            }
        }

    /**
     * Modelo para parsear la respuesta JSON del endpoint de login.
     * Asume que el servidor devuelve: { "token": "eyJ..." }
     * Ajustar según la API real del servidor.
     */
    private data class TokenResponse(
        val token: String = "",
        val expiresIn: Long = 0,
        val type: String = "Bearer"
    )
}
