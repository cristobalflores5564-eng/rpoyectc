package com.remotemonitor.ui.permissions

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.remotemonitor.databinding.FragmentPermissionsBinding
import com.remotemonitor.ui.main.MainViewModel

/**
 * PermissionsFragment
 *
 * Pantalla que muestra el estado de todos los permisos de la app.
 * El usuario puede ver claramente cuáles están concedidos y cuáles no,
 * y solicitar los que faltan con un solo toque.
 *
 * Esta pantalla es importante por dos razones:
 * 1. Transparencia: el usuario siempre sabe qué permisos tiene la app
 * 2. Recuperación: si el usuario denegó un permiso antes, puede concederlo aquí
 */
class PermissionsFragment : Fragment() {

    private var _binding: FragmentPermissionsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()
    private lateinit var adapter: PermissionStatusAdapter
    private lateinit var permissionManager: PermissionManager

    // Launcher para solicitar permisos desde este fragment
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Actualizar la lista después de que el usuario responda
        viewModel.refreshPermissionStatus()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPermissionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        permissionManager = PermissionManager(requireContext())

        setupRecyclerView()
        setupClickListeners()
        setupObservers()
    }

    override fun onResume() {
        super.onResume()
        // Refrescar cuando el usuario regresa de Ajustes del sistema
        viewModel.refreshPermissionStatus()
    }

    private fun setupRecyclerView() {
        adapter = PermissionStatusAdapter(
            onRequestPermission = { permissionInfo ->
                permissionLauncher.launch(arrayOf(permissionInfo.permission))
            },
            onOpenSettings = {
                permissionManager.openAppSettings(requireActivity())
            }
        )

        binding.recyclerViewPermissions.apply {
            this.adapter = this@PermissionsFragment.adapter
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
        }
    }

    private fun setupClickListeners() {
        // Botón "Solicitar todos los permisos faltantes"
        binding.btnRequestAllPermissions.setOnClickListener {
            val missing = permissionManager.buildPermissionArray()
            if (missing.isNotEmpty()) {
                permissionLauncher.launch(missing)
            }
        }

        // Botón "Excluir de optimización de batería"
        binding.btnBatteryOptimization.setOnClickListener {
            permissionManager.requestIgnoreBatteryOptimization(requireActivity())
        }
    }

    private fun setupObservers() {
        viewModel.permissionStatus.observe(viewLifecycleOwner) { statuses ->
            adapter.submitList(statuses)

            // Actualizar estado general
            val allGranted = statuses.all { it.granted }
            if (allGranted) {
                binding.tvOverallStatus.text = "✓ Todos los permisos concedidos"
                binding.btnRequestAllPermissions.isEnabled = false
            } else {
                val missing = statuses.count { !it.granted }
                binding.tvOverallStatus.text = "⚠ $missing permiso(s) sin conceder"
                binding.btnRequestAllPermissions.isEnabled = true
            }
        }

        // Estado de la optimización de batería
        binding.btnBatteryOptimization.isEnabled = !permissionManager.isBatteryOptimizationIgnored()
        if (permissionManager.isBatteryOptimizationIgnored()) {
            binding.tvBatteryOptStatus.text = "✓ App excluida de optimización de batería"
        } else {
            binding.tvBatteryOptStatus.text = "⚠ App sujeta a optimización de batería"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
