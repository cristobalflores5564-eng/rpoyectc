package com.remotemonitor.network

import com.remotemonitor.data.model.ConnectionState
import com.remotemonitor.data.model.ServerConfig
import com.remotemonitor.network.DeviceRegistrationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * WebSocketClient
 *
 * Gestiona la conexión WebSocket segura (wss://) con el servidor remoto.
 *
 * Características:
 * - Reconexión automática exponential backoff (evita saturar el servidor)
 * - Autenticación por token o usuario/contraseña en el handshake HTTP
 * - Comunicación bidireccional: envío de frames de video/audio y recepción de comandos
 * - StateFlow para que el ViewModel observe el estado sin callbacks directos
 *
 * Decisión técnica: OkHttp es la librería más estable y eficiente en Android
 * para WebSockets. Maneja automáticamente el pool de conexiones y TLS.
 */
class WebSocketClient {

    // ===================== ESTADO =====================

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)

    /** StateFlow público (solo lectura) para que el ViewModel lo observe */
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    // ===================== COMPONENTES INTERNOS =====================

    private var webSocket: WebSocket? = null
    private var reconnectJob: Job? = null
    private var currentConfig: ServerConfig? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    // Parámetros de reconexión — cada 10 segundos para siempre
    private var reconnectAttempts = 0
    private val maxReconnectAttempts = Int.MAX_VALUE
    private val baseDelayMs = 10_000L     // 10 segundos fijo
    private val maxDelayMs  = 10_000L     // nunca aumenta

    // Listener de mensajes para que el servicio los reciba
    var onMessageReceived: ((String) -> Unit)? = null
    var onBinaryMessageReceived: ((ByteArray) -> Unit)? = null

    // Contador de fallos consecutivos en sendBinary — si llega a 20 la conexión está muerta
    private var consecutiveSendFailures = 0
    private val MAX_SEND_FAILURES = 20

    /**
     * OkHttpClient configurado para WebSocket seguro.
     *
     * Timeouts:
     * - connect: tiempo máximo para establecer la conexión TCP/TLS
     * - read/write: tiempo de espera entre paquetes (ping/pong)
     * - pingInterval: mantiene viva la conexión enviando pings periódicos
     */
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)   // 60s — el pingInterval mantiene vivo
        .writeTimeout(30, TimeUnit.SECONDS)
        .pingInterval(10, TimeUnit.SECONDS)  // ping cada 10s — bien por debajo del readTimeout
        .build()

    // ===================== CONEXIÓN =====================

    /**
     * Inicia la conexión WebSocket con el servidor (método legacy con ServerConfig).
     *
     * @param config Configuración del servidor con URL, puerto y credenciales
     */
    fun connect(config: ServerConfig) {
        currentConfig = config
        reconnectAttempts = 0
        performConnect(config)
    }

    /**
     * Inicia la conexión usando una URL ya construida completamente.
     * Usado cuando el DeviceRegistrationManager construye la URL con el código
     * y la contraseña incluidos como query params.
     *
     * Ejemplo: wss://guardianlink.bonto.run/ws?code=A3F-K9B-Z2M&password=...&role=device
     */
    fun connectWithUrl(fullUrl: String) {
        fullWsUrl = fullUrl
        reconnectAttempts = 0
        performConnectUrl(fullUrl)
    }

    private var fullWsUrl: String? = null

    private fun performConnect(config: ServerConfig) {
        _connectionState.value = ConnectionState.Connecting

        val wsUrl = config.buildWebSocketUrl()
        Timber.i("Conectando a WebSocket: $wsUrl")

        val requestBuilder = Request.Builder().url(wsUrl)

        when {
            config.token.isNotBlank() -> {
                requestBuilder.addHeader("Authorization", "Bearer ${config.token}")
            }
            config.username.isNotBlank() -> {
                val credentials = okhttp3.Credentials.basic(config.username, config.password)
                requestBuilder.addHeader("Authorization", credentials)
            }
        }

        requestBuilder.addHeader("X-Client-Type", "RemoteMonitorAndroid")
        requestBuilder.addHeader("X-Client-Version", "1.0.0")

        webSocket = okHttpClient.newWebSocket(requestBuilder.build(), createListener())
    }

    private fun performConnectUrl(url: String) {
        _connectionState.value = ConnectionState.Connecting
        Timber.i("Conectando WebSocket con URL de dispositivo")

        // Extraer la contraseña del query param si viene incluida (legacy),
        // o leerla desde la constante directamente
        val password = DeviceRegistrationManager.DEVICE_PASSWORD

        val request = Request.Builder()
            .url(url)
            .addHeader("X-Client-Type", "RemoteMonitorAndroid")
            .addHeader("X-Client-Version", "1.0.0")
            .addHeader("X-Device-Password", password)   // contraseña en header, no en URL
            .build()

        webSocket = okHttpClient.newWebSocket(request, createListener())
    }

    /**
     * Crea el listener de eventos del WebSocket.
     * Todos los callbacks se invocan en los hilos de OkHttp, no en el UI thread.
     */
    private fun createListener() = object : WebSocketListener() {

        override fun onOpen(webSocket: WebSocket, response: Response) {
            Timber.i("WebSocket conectado. Código HTTP: ${response.code}")
            reconnectAttempts = 0
            consecutiveSendFailures = 0
            reconnectJob?.cancel()
            // Usar fullWsUrl si está disponible, sino la de config
            val url = fullWsUrl ?: currentConfig?.buildWebSocketUrl() ?: ""
            _connectionState.value = ConnectionState.Connected(url)
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            Timber.d("Mensaje recibido (texto): ${text.take(100)}") // Log truncado
            onMessageReceived?.invoke(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            Timber.d("Mensaje recibido (binario): ${bytes.size} bytes")
            onBinaryMessageReceived?.invoke(bytes.toByteArray())
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            Timber.i("WebSocket cerrando. Código: $code, Razón: $reason")
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Timber.i("WebSocket cerrado. Código: $code")
            // Emitir Disconnected siempre — MonitoringService.startConnectionLoop() maneja la reconexión
            _connectionState.value = ConnectionState.Disconnected
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            val message = t.message ?: "Error desconocido"
            Timber.e(t, "Fallo en WebSocket: $message")
            if (response?.code == 401) {
                _connectionState.value = ConnectionState.AuthFailed("Credenciales incorrectas")
                return
            }
            // Emitir Error — el bucle del servicio lo detecta y reintenta desde cero
            _connectionState.value = ConnectionState.Error(message, response?.code ?: -1)
        }
    }

    /**
     * Fuerza un estado de error externo (usado por el watchdog del servicio).
     * Cierra el WebSocket actual y emite Error para que startConnectionLoop() reconecte.
     */
    fun forceError(reason: String) {
        Timber.w("forceError: $reason")
        consecutiveSendFailures = 0
        webSocket?.cancel() // cancel() es más agresivo que close(), corta inmediatamente
        webSocket = null
        _connectionState.value = ConnectionState.Error(reason, -1)
    }

    // ===================== RECONEXIÓN =====================

    /**
     * Programa una reconexión con backoff exponencial.
     *
     * Fórmula: delay = min(baseDelay * 2^intento, maxDelay)
     * Esto evita saturar el servidor con reconexiones rápidas.
     *
     * Ejemplo: 2s, 4s, 8s, 16s, 32s, 60s, 60s, 60s...
     */
    private fun scheduleReconnect() {
        // Reconectar usando URL completa si está disponible (modo código de dispositivo)
        val hasFullUrl = fullWsUrl != null
        val config = if (!hasFullUrl) currentConfig else null
        if (!hasFullUrl && config == null) return
        if (!hasFullUrl && config?.autoConnect == false) return
        if (reconnectAttempts >= maxReconnectAttempts) {
            Timber.w("Máximo de reconexiones alcanzado ($maxReconnectAttempts)")
            _connectionState.value = ConnectionState.Error(
                "No se pudo reconectar después de $maxReconnectAttempts intentos"
            )
            return
        }

        reconnectAttempts++
        val delay = 10_000L  // siempre 10 segundos

        Timber.i("Reconexión #$reconnectAttempts en ${delay}ms")
        _connectionState.value = ConnectionState.Reconnecting(reconnectAttempts, maxReconnectAttempts)

        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(delay)
            if (_connectionState.value !is ConnectionState.Connected) {
                val url = fullWsUrl
                if (url != null) {
                    performConnectUrl(url)
                } else {
                    currentConfig?.let { performConnect(it) }
                }
            }
        }
    }

    // ===================== ENVÍO DE DATOS =====================

    /**
     * Envía un mensaje de texto (JSON) al servidor.
     * Retorna false si no hay conexión activa.
     */
    fun sendMessage(message: String): Boolean {
        val ws = webSocket ?: return false
        return try {
            val ok = ws.send(message)
            if (ok) consecutiveSendFailures = 0
            ok
        } catch (e: Exception) {
            Timber.e(e, "Error enviando mensaje")
            false
        }
    }

    /**
     * Envía datos binarios (frame de video/audio) al servidor.
     * Más eficiente que Base64 para datos multimedia.
     * Si falla MAX_SEND_FAILURES veces consecutivas, la conexión se considera muerta
     * y se emite Error para que MonitoringService fuerce reconexión.
     */
    fun sendBinary(data: ByteArray): Boolean {
        val ws = webSocket ?: return false
        return try {
            val ok = ws.send(ByteString.of(*data))
            if (ok) {
                consecutiveSendFailures = 0
            } else {
                consecutiveSendFailures++
                Timber.w("sendBinary falló ($consecutiveSendFailures/$MAX_SEND_FAILURES)")
                // Solo forzar reconexión si llevamos muchos fallos seguidos.
                // Un fallo aislado (buffer lleno momentáneo) NO debe matar la conexión.
                if (consecutiveSendFailures >= MAX_SEND_FAILURES) {
                    Timber.e("Demasiados fallos de envío — conexión zombie, forzando reconexión")
                    consecutiveSendFailures = 0
                    forceError("Send buffer lleno — conexión zombie")
                }
            }
            ok
        } catch (e: Exception) {
            Timber.e(e, "Error enviando datos binarios")
            // Solo forzar reconexión en excepción real, no en backpressure normal
            consecutiveSendFailures++
            if (consecutiveSendFailures >= MAX_SEND_FAILURES) {
                consecutiveSendFailures = 0
                forceError("Excepción persistente en sendBinary: ${e.message}")
            }
            false
        }
    }

    // ===================== DESCONEXIÓN =====================

    /**
     * Cierra la conexión limpiamente.
     * Código 1000 = cierre normal según el estándar WebSocket (RFC 6455).
     */
    fun disconnect() {
        reconnectJob?.cancel()
        reconnectJob = null
        currentConfig = null
        fullWsUrl = null
        reconnectAttempts = 0
        consecutiveSendFailures = 0
        webSocket?.close(1000, "Desconexión solicitada por el usuario")
        webSocket = null
        _connectionState.value = ConnectionState.Disconnected
        Timber.i("WebSocket desconectado por el usuario")
    }

    /**
     * Libera los recursos del cliente HTTP.
     * Llamar al destruir el servicio.
     */
    fun shutdown() {
        disconnect()
        okHttpClient.dispatcher.executorService.shutdown()
        okHttpClient.connectionPool.evictAll()
    }
}
