package com.remotemonitor.ui.settings

import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.remotemonitor.R
import com.remotemonitor.data.model.ServerConfig
import com.remotemonitor.data.model.VideoQuality
import com.remotemonitor.data.model.VideoResolution
import com.remotemonitor.data.preferences.PreferencesManager
import com.remotemonitor.databinding.ActivitySettingsBinding
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * SettingsActivity
 *
 * Pantalla de configuración del servidor y parámetros de video.
 *
 * Campos editables:
 * - URL del servidor
 * - Puerto
 * - Usuario y contraseña
 * - Token de autenticación
 * - Usar TLS (toggle)
 * - Calidad de video (dropdown)
 * - Resolución (dropdown)
 * - FPS
 * - Auto-conectar al iniciar
 * - Iniciar al arrancar el teléfono
 *
 * Usa un ViewModel propio (SettingsViewModel) para no contaminar el MainViewModel
 * con lógica de configuración.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var preferencesManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mostrar flecha de "volver" en la toolbar
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = getString(R.string.settings_title)

        preferencesManager = PreferencesManager(this)

        setupDropdowns()
        loadCurrentConfig()
        setupClickListeners()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    // ===================== DROPDOWNS =====================

    private fun setupDropdowns() {
        // Dropdown de calidad de video
        val qualities = VideoQuality.values().map { it.displayName }
        val qualityAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, qualities)
        binding.actvVideoQuality.setAdapter(qualityAdapter)

        // Dropdown de resolución
        val resolutions = VideoResolution.values().map { it.displayName }
        val resAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, resolutions)
        binding.actvResolution.setAdapter(resAdapter)
    }

    // ===================== CARGAR CONFIGURACIÓN =====================

    private fun loadCurrentConfig() {
        lifecycleScope.launch {
            val config = preferencesManager.serverConfigFlow.first()
            populateFields(config)

            // Cargar preferencia de inicio automático
            val autoStart = preferencesManager.autoStartOnBoot.first()
            binding.switchAutoStart.isChecked = autoStart
        }
    }

    private fun populateFields(config: ServerConfig) {
        binding.etServerUrl.setText(config.serverUrl)
        binding.etPort.setText(config.port.toString())
        binding.etUsername.setText(config.username)
        binding.etPassword.setText(config.password)
        binding.etToken.setText(config.token)
        binding.switchTls.isChecked = config.useTls
        binding.etFps.setText(config.fps.toString())
        binding.switchAutoConnect.isChecked = config.autoConnect
        binding.actvVideoQuality.setText(config.videoQuality.displayName, false)
        binding.actvResolution.setText(config.resolution.displayName, false)
    }

    // ===================== GUARDAR CONFIGURACIÓN =====================

    private fun setupClickListeners() {
        binding.btnSave.setOnClickListener {
            saveConfig()
        }

        binding.btnTestConnection.setOnClickListener {
            testConnection()
        }

        // Toggle de TLS actualiza el esquema de la URL en tiempo real
        binding.switchTls.setOnCheckedChangeListener { _, isChecked ->
            val currentUrl = binding.etServerUrl.text.toString()
            if (isChecked && currentUrl.startsWith("http://")) {
                binding.etServerUrl.setText(currentUrl.replace("http://", "https://"))
            }
        }
    }

    private fun saveConfig() {
        // Validar campos obligatorios
        val url  = binding.etServerUrl.text.toString().trim()
        val port = binding.etPort.text.toString().trim().toIntOrNull()
        val fps  = binding.etFps.text.toString().trim().toIntOrNull() ?: 15

        if (url.isBlank() || url == "https://") {
            binding.tilServerUrl.error = "La URL del servidor es obligatoria"
            return
        }
        if (port == null || port !in 1..65535) {
            binding.tilPort.error = "Puerto inválido (1-65535)"
            return
        }

        // Limpiar errores previos
        binding.tilServerUrl.error = null
        binding.tilPort.error = null

        // Mapear dropdown a enum
        val selectedQuality = VideoQuality.values().find {
            it.displayName == binding.actvVideoQuality.text.toString()
        } ?: VideoQuality.MEDIUM

        val selectedResolution = VideoResolution.values().find {
            it.displayName == binding.actvResolution.text.toString()
        } ?: VideoResolution.HD_720P

        val newConfig = ServerConfig(
            serverUrl    = url,
            port         = port,
            username     = binding.etUsername.text.toString().trim(),
            password     = binding.etPassword.text.toString(),
            token        = binding.etToken.text.toString().trim(),
            useTls       = binding.switchTls.isChecked,
            videoQuality = selectedQuality,
            resolution   = selectedResolution,
            fps          = fps.coerceIn(1, 60),
            autoConnect  = binding.switchAutoConnect.isChecked
        )

        lifecycleScope.launch {
            preferencesManager.saveServerConfig(newConfig)
            preferencesManager.setAutoStartOnBoot(binding.switchAutoStart.isChecked)
            Toast.makeText(
                this@SettingsActivity,
                getString(R.string.settings_saved),
                Toast.LENGTH_SHORT
            ).show()
            finish()
        }
    }

    private fun testConnection() {
        val url = binding.etServerUrl.text.toString().trim()
        if (url.isBlank()) {
            Toast.makeText(this, "Ingresa la URL del servidor primero", Toast.LENGTH_SHORT).show()
            return
        }
        // TODO: implementar ping HTTP para verificar que el servidor responde
        Toast.makeText(this, "Prueba de conexión: próximamente", Toast.LENGTH_SHORT).show()
    }
}
