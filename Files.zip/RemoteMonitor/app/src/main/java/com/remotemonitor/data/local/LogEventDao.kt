package com.remotemonitor.data.local

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.remotemonitor.data.model.LogEvent
import com.remotemonitor.data.model.LogLevel

/**
 * LogEventDao
 *
 * Data Access Object (DAO) para la tabla de logs.
 * Room genera la implementación SQL automáticamente a partir de estas anotaciones.
 *
 * Todas las operaciones de base de datos deben ejecutarse en un hilo secundario
 * (Room lanza excepción si se llaman en el hilo principal).
 * Las coroutines (suspend) manejan esto automáticamente.
 */
@Dao
interface LogEventDao {

    /**
     * Inserta un nuevo evento de log.
     * IGNORE = si hay conflicto de clave primaria, simplemente lo ignora.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(event: LogEvent)

    /**
     * Retorna todos los eventos ordenados del más reciente al más antiguo.
     * LiveData hace que la UI se actualice automáticamente cuando cambian los datos.
     */
    @Query("SELECT * FROM log_events ORDER BY timestamp DESC")
    fun getAllEventsLiveData(): LiveData<List<LogEvent>>

    /**
     * Retorna los últimos N eventos (para carga inicial sin saturar la UI).
     */
    @Query("SELECT * FROM log_events ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentEvents(limit: Int = 100): List<LogEvent>

    /**
     * Filtra eventos por nivel de severidad.
     */
    @Query("SELECT * FROM log_events WHERE level = :level ORDER BY timestamp DESC")
    fun getEventsByLevel(level: LogLevel): LiveData<List<LogEvent>>

    /**
     * Elimina eventos más antiguos que el timestamp dado.
     * Se usa para limpiar logs viejos y no ocupar demasiado espacio.
     */
    @Query("DELETE FROM log_events WHERE timestamp < :olderThan")
    suspend fun deleteOldEvents(olderThan: Long)

    /**
     * Elimina todos los eventos (útil para el botón "Limpiar logs").
     */
    @Query("DELETE FROM log_events")
    suspend fun deleteAll()

    /**
     * Cuenta total de registros (para estadísticas).
     */
    @Query("SELECT COUNT(*) FROM log_events")
    suspend fun count(): Int
}
