package com.remotemonitor.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.remotemonitor.R
import com.remotemonitor.data.model.ConnectionState
import com.remotemonitor.databinding.FragmentHomeBinding

/**
 * HomeFragment
 *
 * Pantalla principal de la app. Muestra:
 * - Estado de la conexión con el servidor (conectado/desconectado/error)
 * - Estado del servicio de monitoreo (activo/inactivo)
 * - Botón para iniciar o detener el servicio
 * - Resumen de permisos concedidos
 * - Información del servidor configurado
 *
 * Usa activityViewModels() para compartir el mismo ViewModel con MainActivity
 * y otros fragments, garantizando un único estado de verdad.
 */
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    // _binding puede ser null fuera del ciclo onCreateView/onDestroyView
    private val binding get() = _binding!!

    // activityViewModels = ViewModel scoped a la Activity, compartido entre todos los fragments
    private val viewModel: MainViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListeners()
        setupObservers()
    }

    private fun setupClickListeners() {
        // Botón principal: toggle del servicio
        binding.btnToggleService.setOnClickListener {
            viewModel.toggleService()
        }
    }

    private fun setupObservers() {

        // ===================== CÓDIGO DEL DISPOSITIVO =====================
        viewModel.deviceCode.observe(viewLifecycleOwner) { code ->
            if (code != null) {
                binding.tvDeviceCode.text = code
                binding.tvDeviceCode.visibility = android.view.View.VISIBLE
                binding.tvDeviceCodeLabel.visibility = android.view.View.VISIBLE
            } else {
                binding.tvDeviceCode.text = "Pendiente de registro..."
                binding.tvDeviceCode.visibility = android.view.View.VISIBLE
                binding.tvDeviceCodeLabel.visibility = android.view.View.VISIBLE
            }
        }

        // ===================== ESTADO DEL SERVICIO =====================
        viewModel.serviceRunning.observe(viewLifecycleOwner) { running ->
            if (running) {
                binding.btnToggleService.text = getString(R.string.action_stop)
                binding.btnToggleService.setIconResource(R.drawable.ic_stop)
                binding.serviceStatusIndicator.setImageResource(R.drawable.ic_circle_green)
                binding.tvServiceStatus.text = getString(R.string.service_status_active)
            } else {
                binding.btnToggleService.text = getString(R.string.action_start)
                binding.btnToggleService.setIconResource(R.drawable.ic_play)
                binding.serviceStatusIndicator.setImageResource(R.drawable.ic_circle_red)
                binding.tvServiceStatus.text = getString(R.string.service_status_inactive)
            }
        }

        // ===================== ESTADO DE CONEXIÓN =====================
        viewModel.connectionState.observe(viewLifecycleOwner) { state ->
            binding.tvConnectionStatus.text = state.toDisplayString()

            // Color del indicador según el estado
            val colorRes = when (state) {
                is ConnectionState.Connected    -> R.color.connection_connected
                is ConnectionState.Connecting,
                is ConnectionState.Reconnecting -> R.color.connection_connecting
                is ConnectionState.Error,
                is ConnectionState.AuthFailed   -> R.color.connection_error
                is ConnectionState.Disconnected -> R.color.connection_disconnected
            }
            binding.connectionStatusCard.setCardBackgroundColor(
                requireContext().getColor(colorRes)
            )
        }

        // ===================== CONFIGURACIÓN DEL SERVIDOR =====================
        viewModel.serverConfig.observe(viewLifecycleOwner) { config ->
            if (config.serverUrl == "https://" || config.serverUrl.isBlank()) {
                binding.tvServerInfo.text = getString(R.string.server_not_configured)
                binding.btnToggleService.isEnabled = false
            } else {
                binding.tvServerInfo.text = getString(
                    R.string.server_info_format,
                    config.serverUrl,
                    config.port
                )
                binding.btnToggleService.isEnabled = true
            }
        }

        // ===================== ESTADO DE PERMISOS =====================
        viewModel.allPermissionsGranted.observe(viewLifecycleOwner) { allGranted ->
            if (allGranted) {
                binding.tvPermissionsStatus.text = getString(R.string.permissions_all_granted)
                binding.tvPermissionsStatus.setTextColor(
                    requireContext().getColor(R.color.status_ok)
                )
            } else {
                binding.tvPermissionsStatus.text = getString(R.string.permissions_missing)
                binding.tvPermissionsStatus.setTextColor(
                    requireContext().getColor(R.color.status_warning)
                )
            }
        }
    }

    // Limpiar el binding al destruir la vista para evitar memory leaks
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
