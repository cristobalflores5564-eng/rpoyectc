package com.remotemonitor.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.remotemonitor.service.MonitoringService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * BootReceiver
 *
 * BroadcastReceiver que escucha el evento BOOT_COMPLETED del sistema.
 * Android lo envía después de que el sistema termina de arrancar completamente.
 *
 * Nota importante sobre Android 10+:
 * A partir de Android 10, hay restricciones para iniciar servicios en segundo plano
 * directamente desde BroadcastReceiver. Por eso usamos startForegroundService()
 * en lugar de startService(), y el servicio llama a startForeground() inmediatamente.
 *
 * El usuario debe haber habilitado "Inicio automático" en la configuración de la app
 * Y la app debe estar excluida de la optimización de batería para funcionar
 * correctamente en todos los fabricantes (Samsung, Huawei, Xiaomi, etc.)
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        // Verificar que sea uno de los intents de arranque del sistema
        val isBootIntent = action == Intent.ACTION_BOOT_COMPLETED ||
                action == "android.intent.action.QUICKBOOT_POWERON" ||
                action == "com.htc.intent.action.QUICKBOOT_POWERON"

        if (!isBootIntent) return

        Timber.i("BootReceiver: dispositivo reiniciado, verificando configuración...")

        // Leer la preferencia de inicio automático antes de iniciar el servicio.
        // No podemos usar suspend directamente en onReceive, por eso usamos
        // goAsync() + coroutine para leer el DataStore sin bloquear.
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Auto-start siempre activo — la app está diseñada para correr en segundo plano
                val autoStart = true

                if (autoStart) {
                    Timber.i("Iniciando MonitoringService después del arranque")
                    startMonitoringService(context)
                } else {
                    Timber.i("Inicio automático deshabilitado, no se inicia el servicio")
                }
            } catch (e: Exception) {
                Timber.e(e, "Error en BootReceiver al leer preferencias")
            } finally {
                // IMPORTANTE: siempre llamar finish() para liberar el WakeLock del sistema
                pendingResult.finish()
            }
        }
    }

    /**
     * Inicia el MonitoringService como ForegroundService.
     *
     * En Android 8+ se DEBE usar startForegroundService() cuando se llama
     * desde un componente en segundo plano (como este BroadcastReceiver).
     * El servicio tiene 5 segundos para llamar startForeground() o Android lo mata.
     */
    private fun startMonitoringService(context: Context) {
        val serviceIntent = MonitoringService.startIntent(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
