package com.remotemonitor.data.model

/**
 * DeviceRegistration
 *
 * Representa el resultado del registro del teléfono en el servidor.
 * El código se genera UNA SOLA VEZ al instalar la app y se guarda permanentemente
 * en las preferencias del dispositivo.
 *
 * Flujo:
 *  1. App instala → llama POST /api/register-device
 *  2. Servidor genera código único (ej: "A3F-K9B-Z2M")
 *  3. App guarda el código en DataStore (persiste entre reinicios)
 *  4. Ese código identifica al teléfono para siempre
 *  5. Al conectar WebSocket: ws://servidor/ws?code=A3F-K9B-Z2M&password=MeCa12345@123&role=device
 */
data class DeviceRegistration(
    val code: String,      // Código único del teléfono (ej: "A3F-K9B-Z2M")
    val label: String,     // Nombre asignado por el servidor (ej: "Teléfono 1")
    val existing: Boolean  // true = ya estaba registrado, false = nuevo registro
)
