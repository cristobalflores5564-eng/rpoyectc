package com.remotemonitor.data.model

/**
 * ConnectionState
 *
 * Representa el estado actual de la conexión con el servidor remoto.
 * Es un sealed class: solo puede tener los estados definidos aquí,
 * lo que permite un exhaustive when() en la UI sin necesidad de else.
 *
 * Usado por el ViewModel para notificar a la UI mediante LiveData.
 */
sealed class ConnectionState {

    /** No hay intento de conexión activo */
    object Disconnected : ConnectionState()

    /** Intentando establecer la conexión */
    object Connecting : ConnectionState()

    /** Conexión establecida y activa */
    data class Connected(val serverUrl: String) : ConnectionState()

    /** Reconectando después de una pérdida de conexión */
    data class Reconnecting(val attempt: Int, val maxAttempts: Int) : ConnectionState()

    /** Error en la conexión con mensaje descriptivo */
    data class Error(val message: String, val code: Int = -1) : ConnectionState()

    /** Autenticación fallida */
    data class AuthFailed(val reason: String) : ConnectionState()

    /**
     * Retorna true si actualmente hay una sesión activa con el servidor.
     */
    fun isActive(): Boolean = this is Connected

    /**
     * Retorna true si hay alguna operación en progreso (conectando o reconectando).
     */
    fun isInProgress(): Boolean = this is Connecting || this is Reconnecting

    /**
     * Retorna un mensaje legible para mostrar en la UI.
     */
    fun toDisplayString(): String = when (this) {
        is Disconnected  -> "Desconectado"
        is Connecting    -> "Conectando..."
        is Connected     -> "Conectado a $serverUrl"
        is Reconnecting  -> "Reconectando... ($attempt/$maxAttempts)"
        is Error         -> "Error: $message"
        is AuthFailed    -> "Autenticación fallida: $reason"
    }
}
