package com.remotemonitor.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.remotemonitor.R
import com.remotemonitor.RemoteMonitorApp
import com.remotemonitor.data.local.AppDatabase
import com.remotemonitor.data.model.ConnectionState
import com.remotemonitor.data.preferences.PreferencesManager
import com.remotemonitor.data.repository.LogRepository
import com.remotemonitor.network.AuthManager
import com.remotemonitor.network.DeviceRegistrationManager
import com.remotemonitor.network.WebSocketClient
import com.remotemonitor.ui.main.MainActivity
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.ByteArrayOutputStream
import android.graphics.Bitmap
import android.graphics.BitmapFactory

class MonitoringService : LifecycleService() {

    private lateinit var webSocketClient: WebSocketClient
    private lateinit var authManager: AuthManager
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var registrationManager: DeviceRegistrationManager
    private lateinit var logRepository: LogRepository
    private lateinit var wakeLock: PowerManager.WakeLock
    private lateinit var notificationManager: NotificationManager

    // ── Camera2 ───────────────────────────────────────────────────────────────
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var cameraThread: HandlerThread? = null
    private var cameraHandler: Handler? = null

    @Volatile private var isStreaming = false
    private var lastFrameTime = 0L
    private val FRAME_INTERVAL_MS = 100L  // 10 fps

    private var lensFacing = CameraCharacteristics.LENS_FACING_BACK
    private var statusJob: Job? = null
    private var cameraWatchdogJob: Job? = null
    private var currentDeviceCode: String? = null

    @Volatile private var lastFrameSentMs = 0L

    companion object {
        const val ACTION_START = "com.remotemonitor.action.START"
        const val ACTION_STOP  = "com.remotemonitor.action.STOP"
        const val TAG = "MonitoringService"
        fun startIntent(ctx: Context) = Intent(ctx, MonitoringService::class.java).apply { action = ACTION_START }
        fun stopIntent(ctx: Context)  = Intent(ctx, MonitoringService::class.java).apply { action = ACTION_STOP  }
    }

    // ── Ciclo de vida ─────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        webSocketClient     = WebSocketClient()
        authManager         = AuthManager()
        preferencesManager  = PreferencesManager(this)
        registrationManager = DeviceRegistrationManager(this)
        notificationManager = getSystemService(NotificationManager::class.java)
        val db = AppDatabase.getInstance(this)
        logRepository = LogRepository(db.logEventDao())
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RemoteMonitor::WakeLock")
        observeConnectionState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> handleStart()
            ACTION_STOP  -> handleStop()
            else         -> handleStart()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }

    override fun onDestroy() {
        stopCamera()
        stopStatusLoop()
        stopCameraWatchdog()
        webSocketClient.shutdown()
        releaseWakeLock()
        super.onDestroy()
    }

    // ── Inicio / Parada ───────────────────────────────────────────────────────

    private fun handleStart() {
        startForeground(RemoteMonitorApp.NOTIFICATION_ID_SERVICE, buildNotification("Iniciando...", null))
        acquireWakeLock()
        startConnectionLoop()
    }

    private fun startConnectionLoop() {
        lifecycleScope.launch {
            while (true) {
                val ok = tryConnectOnce()
                if (ok) {
                    // Esperar desconexión real
                    webSocketClient.connectionState.first {
                        it is ConnectionState.Disconnected ||
                        it is ConnectionState.Error ||
                        it is ConnectionState.AuthFailed
                    }
                    stopCamera()
                    stopAudioStream()
                    stopCameraWatchdog()
                    updateNotification("Reconectando...", currentDeviceCode)
                }
                kotlinx.coroutines.delay(5_000L)
            }
        }
    }

    private suspend fun tryConnectOnce(): Boolean {
        return try {
            val config = preferencesManager.serverConfigFlow.first()
            updateNotification("Conectando...", currentDeviceCode)

            val regResult = registrationManager.registerDevice(config)
            val deviceCode = when (regResult) {
                is DeviceRegistrationManager.RegistrationResult.Success         -> regResult.registration.code
                is DeviceRegistrationManager.RegistrationResult.AlreadyRegistered -> regResult.code
                is DeviceRegistrationManager.RegistrationResult.Failure         -> null
            } ?: return false

            currentDeviceCode = deviceCode
            val wsUrl = registrationManager.buildDeviceWebSocketUrl(config) ?: return false

            webSocketClient.connectWithUrl(wsUrl)
            webSocketClient.onMessageReceived = { msg -> handleServerMessage(msg) }
            startStatusLoop()
            true
        } catch (e: Exception) {
            logRepository.logError(TAG, "Error conectando: ${e.message}", e)
            false
        }
    }

    private fun handleStop() {
        stopCamera()
        stopStatusLoop()
        stopCameraWatchdog()
        webSocketClient.disconnect()
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ── Mensajes del servidor ─────────────────────────────────────────────────

    private fun handleServerMessage(message: String) {
        try {
            val json = org.json.JSONObject(message)
            when (json.optString("type")) {
                "ping"    -> webSocketClient.sendMessage("{\"type\":\"pong\"}")
                "heartbeat" -> { /* ignorar */ }
                "command" -> processCommand(json.optString("action"), json.optJSONObject("params"))
            }
        } catch (_: Exception) {}
    }

    private fun processCommand(action: String, params: org.json.JSONObject?) {
        // Los comandos llegan desde el callback de OkHttp (hilo IO).
        // Despachar al lifecycleScope para no bloquear ese hilo con operaciones de cámara.
        lifecycleScope.launch {
            when (action) {
                "ping"        -> webSocketClient.sendMessage("{\"type\":\"pong\"}")
                "flash_on"    -> setFlash(true)
                "flash_off"   -> setFlash(false)
                "camera_rear" -> switchCamera(CameraCharacteristics.LENS_FACING_BACK)
                "camera_front"-> switchCamera(CameraCharacteristics.LENS_FACING_FRONT)
                "start_audio" -> startAudioStream()
                "stop_audio"  -> stopAudioStream()
                "snapshot"    -> { /* streaming continuo activo */ }
            }
        }
    }

    // ── Camera2 ───────────────────────────────────────────────────────────────

    @SuppressLint("MissingPermission")
    private fun startCamera() {
        // Si ya hay una sesión activa Y la cámara está completamente abierta, no arrancar de nuevo
        if (isStreaming && cameraDevice != null && captureSession != null) return
        // Asegurar estado limpio antes de abrir (por si quedaron restos de un cierre parcial)
        if (cameraDevice != null || cameraThread != null) {
            stopCamera()
        }
        try {
            cameraThread = HandlerThread("CameraThread").also { it.start() }
            cameraHandler = Handler(cameraThread!!.looper)

            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == lensFacing
            } ?: return

            imageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2)
            imageReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    val now = System.currentTimeMillis()
                    if (now - lastFrameTime < FRAME_INTERVAL_MS) { image.close(); return@setOnImageAvailableListener }
                    lastFrameTime = now

                    val buffer = image.planes[0].buffer
                    val raw = ByteArray(buffer.remaining()).also { buffer.get(it) }
                    val compressed = compressJpeg(raw, 70)

                    if (webSocketClient.connectionState.value is ConnectionState.Connected) {
                        // Actualizar timestamp siempre que la cámara produzca frames,
                        // independientemente de si el envío tuvo éxito o no.
                        // Así el watchdog no reinicia la cámara por backpressure momentáneo de red.
                        lastFrameSentMs = System.currentTimeMillis()
                        webSocketClient.sendBinary(compressed)
                    }
                } finally { image.close() }
            }, cameraHandler)

            cm.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(cam: CameraDevice) {
                    cameraDevice = cam
                    createCaptureSession()
                    isStreaming = true
                    updateNotification("Streaming activo", currentDeviceCode)
                    startCameraWatchdog()
                }
                override fun onDisconnected(cam: CameraDevice) {
                    cam.close(); cameraDevice = null; isStreaming = false
                    logRepository.logWarning(TAG, "Cámara desconectada")
                }
                override fun onError(cam: CameraDevice, error: Int) {
                    cam.close(); cameraDevice = null; isStreaming = false
                    logRepository.logError(TAG, "Error cámara: $error")
                }
            }, cameraHandler)

        } catch (e: Exception) {
            logRepository.logError(TAG, "Error abriendo cámara: ${e.message}", e)
        }
    }

    private fun createCaptureSession() {
        val cam    = cameraDevice ?: return
        val reader = imageReader   ?: return
        cam.createCaptureSession(listOf(reader.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(session: CameraCaptureSession) {
                captureSession = session
                val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                    addTarget(reader.surface)
                    set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                }.build()
                session.setRepeatingRequest(req, null, cameraHandler)
            }
            override fun onConfigureFailed(session: CameraCaptureSession) {
                logRepository.logError(TAG, "Fallo configurando sesión de cámara")
                isStreaming = false
            }
        }, cameraHandler)
    }

    private fun stopCamera() {
        isStreaming = false
        try { captureSession?.close() } catch (_: Exception) {}
        try { cameraDevice?.close()   } catch (_: Exception) {}
        try { imageReader?.close()    } catch (_: Exception) {}
        captureSession = null; cameraDevice = null; imageReader = null
        cameraThread?.quitSafely()
        // NO hacer join aquí — puede llamarse desde el hilo de OkHttp (callback de mensaje)
        // y bloquear 500ms causaría que el servidor detecte timeout de ping y cierre el WS.
        // El HandlerThread termina solo después de quitSafely(); no necesitamos esperar.
        cameraThread = null; cameraHandler = null
    }

    /**
     * Watchdog de cámara: detecta cuando deja de producir frames y la reinicia.
     * NO corta el WebSocket — solo reinicia la cámara.
     */
    private fun startCameraWatchdog() {
        stopCameraWatchdog()
        lastFrameSentMs = System.currentTimeMillis()
        cameraWatchdogJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(15_000L) // dar tiempo al arranque
            while (isActive) {
                kotlinx.coroutines.delay(5_000L)
                if (webSocketClient.connectionState.value !is ConnectionState.Connected) continue
                val gap = System.currentTimeMillis() - lastFrameSentMs
                if (gap > 10_000L) {
                    logRepository.logWarning(TAG, "Watchdog: sin frames en ${gap/1000}s — reiniciando cámara")
                    stopCamera()
                    kotlinx.coroutines.delay(300L)
                    startCamera()
                }
            }
        }
    }

    private fun stopCameraWatchdog() {
        cameraWatchdogJob?.cancel()
        cameraWatchdogJob = null
    }

    private fun compressJpeg(input: ByteArray, quality: Int): ByteArray {
        return try {
            val bmp = BitmapFactory.decodeByteArray(input, 0, input.size) ?: return input
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bmp.recycle()
            out.toByteArray()
        } catch (_: Exception) { input }
    }

    // ── Flash ─────────────────────────────────────────────────────────────────

    private fun setFlash(on: Boolean) {
        try {
            val session = captureSession; val cam = cameraDevice; val reader = imageReader
            if (session != null && cam != null && reader != null) {
                val req = cam.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                    addTarget(reader.surface)
                    if (on) {
                        set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_TORCH)
                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                    } else {
                        set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF)
                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                    }
                }.build()
                session.setRepeatingRequest(req, null, cameraHandler)
            }
        } catch (e: Exception) { logRepository.logError(TAG, "Error flash: ${e.message}", e) }
    }

    private suspend fun switchCamera(facing: Int) {
        lensFacing = facing
        stopCamera()
        // Dar tiempo al sistema para liberar la cámara antes de reabrirla
        kotlinx.coroutines.delay(400L)
        startCamera()
    }

    // ── Telemetría ────────────────────────────────────────────────────────────

    private fun startStatusLoop() {
        statusJob?.cancel()
        statusJob = lifecycleScope.launch {
            while (isActive) {
                if (webSocketClient.connectionState.value is ConnectionState.Connected) sendDeviceStatus()
                kotlinx.coroutines.delay(4_000L)
            }
        }
    }

    private fun stopStatusLoop() { statusJob?.cancel(); statusJob = null }

    private fun sendDeviceStatus() {
        val bm = getSystemService(BatteryManager::class.java)
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        webSocketClient.sendMessage("""{"type":"device_status","battery":$pct,"charging":$charging}""")
    }

    // ── Audio ─────────────────────────────────────────────────────────────────

    private var audioRecord: android.media.AudioRecord? = null
    private var audioThread: Thread? = null
    private var isAudioStreaming = false

    @SuppressLint("MissingPermission")
    private fun startAudioStream() {
        if (isAudioStreaming) return
        try {
            val rate = 16000
            val bufSz = android.media.AudioRecord.getMinBufferSize(rate,
                android.media.AudioFormat.CHANNEL_IN_MONO,
                android.media.AudioFormat.ENCODING_PCM_16BIT) * 2
            audioRecord = android.media.AudioRecord(
                android.media.MediaRecorder.AudioSource.MIC, rate,
                android.media.AudioFormat.CHANNEL_IN_MONO,
                android.media.AudioFormat.ENCODING_PCM_16BIT, bufSz)
            if (audioRecord?.state != android.media.AudioRecord.STATE_INITIALIZED) return
            isAudioStreaming = true
            audioRecord?.startRecording()
            audioThread = Thread {
                val buf = ByteArray(bufSz)
                while (isAudioStreaming) {
                    val read = audioRecord?.read(buf, 0, bufSz) ?: break
                    if (read > 0 && webSocketClient.connectionState.value is ConnectionState.Connected) {
                        val b64 = android.util.Base64.encodeToString(buf.copyOf(read), android.util.Base64.NO_WRAP)
                        webSocketClient.sendMessage("{\"type\":\"audio_chunk\",\"data\":\"$b64\"}")
                    }
                }
            }.also { it.start() }
        } catch (e: Exception) { logRepository.logError(TAG, "Error audio: ${e.message}", e) }
    }

    private fun stopAudioStream() {
        isAudioStreaming = false
        try { audioRecord?.stop(); audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        try { audioThread?.join(500) } catch (_: Exception) {}
        audioThread = null
    }

    // ── Estado de conexión ────────────────────────────────────────────────────

    private fun observeConnectionState() {
        lifecycleScope.launch {
            webSocketClient.connectionState.collect { state ->
                val status = when (state) {
                    is ConnectionState.Connected    -> {
                        // Solo arrancar la cámara si no hay ya una sesión activa
                        if (cameraDevice == null || captureSession == null) {
                            startCamera()
                        }
                        sendDeviceStatus()
                        "Streaming activo"
                    }
                    is ConnectionState.Connecting   -> "Conectando..."
                    is ConnectionState.Reconnecting -> "Reconectando..."
                    is ConnectionState.Disconnected -> { stopCamera(); stopAudioStream(); stopCameraWatchdog(); "Desconectado" }
                    is ConnectionState.Error        -> { stopCamera(); stopAudioStream(); stopCameraWatchdog(); "Sin conexión" }
                    is ConnectionState.AuthFailed   -> { stopCamera(); stopAudioStream(); stopCameraWatchdog(); "Auth fallida" }
                }
                updateNotification(status, currentDeviceCode)
            }
        }
    }

    // ── Notificación ──────────────────────────────────────────────────────────

    private fun buildNotification(text: String, code: String?): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title = if (!code.isNullOrBlank()) "Código: $code" else text
        return NotificationCompat.Builder(this, RemoteMonitorApp.CHANNEL_ID_SERVICE)
            .setContentTitle(title).setContentText(text)
            .setSmallIcon(R.drawable.ic_monitoring)
            .setContentIntent(pi).setOngoing(true).setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun updateNotification(text: String, code: String?) {
        notificationManager.notify(RemoteMonitorApp.NOTIFICATION_ID_SERVICE, buildNotification(text, code))
    }

    // ── WakeLock ──────────────────────────────────────────────────────────────

    private fun acquireWakeLock() { if (!wakeLock.isHeld) wakeLock.acquire(4 * 60 * 60 * 1000L) }
    private fun releaseWakeLock() { if (wakeLock.isHeld) wakeLock.release() }
}
